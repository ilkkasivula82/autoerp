# AutoERP – autokaupan toiminnanohjaus (versio 0.1)

Ensimmäinen runko N247 Finland Oy:n käyttöön. Tukkukauppa: autot ostetaan
rahoitusyhtiöiltä, huutokaupoista ja liikkeiltä ja myydään toisille liikkeille.

## Käynnistys paikallisesti

```bash
pip install -r requirements.txt
flask --app wsgi init-db      # luo tietokannan + demoautot
python wsgi.py                # http://127.0.0.1:5000
```

Kirjautuminen: `admin@n247.fi` / `vaihda-heti`
Demokäyttäjät (salasana `demo`): `osto@n247.fi`, `myynti@n247.fi`, `piha@n247.fi`

Tyhjä tietokanta ilman demoautoja: `SEED_DEMO=0 flask --app wsgi init-db`
Oma ylläpitäjä: `ADMIN_EMAIL=... ADMIN_SALASANA=... flask --app wsgi init-db`

## Tuotantoon (Render)

1. Luo Renderissä PostgreSQL-tietokanta ja Web Service tästä reposta.
2. Build: `pip install -r requirements.txt`
   Start: `gunicorn wsgi:app`
3. Ympäristömuuttujat: `DATABASE_URL` (Renderin Postgres), `SECRET_KEY` (pitkä satunnainen merkkijono),
   `SEED_DEMO=0`, `ADMIN_EMAIL`, `ADMIN_SALASANA`.
4. Aja kerran Renderin Shellissä: `flask --app wsgi init-db`

Kuvat tallentuvat nyt palvelimen levylle (`UPLOAD_DIR`). Renderin levy tyhjenee
uudelleenkäynnistyksessä, joten ennen tuotantokäyttöä `app/storage.py` vaihdetaan
Cloudflare R2:een samalla tavalla kuin tositesovelluksessa (vain tallenna/avaa/poista muuttuvat).

## Tietomallin ydinajatus

| Taulu | Mitä | Miksi |
|---|---|---|
| `ajoneuvo` | Fyysinen auto: VIN, rekisteri, merkki, malli, tekniset tiedot, **varusteet** | Sama auto voi tulla meille monta kertaa. |
| `kierto` | Yksi kierros: tarjous → osto → … → myynti → toimitus. Hinnat, tila, km, kunto, kuvat, kulut, tehtävät | Vuosi sitten myyty auto, joka palaa, saa **uuden kierroksen**. Vanha kierros ja sen kate pysyvät koskemattomina. |

- **Palaava auto tunnistetaan** VIN:llä ensin ja sitten rekisterillä (`ABC123`, `abc-123` ja `ABC 123` ovat sama).
  Uusi-lomake kertoo heti, jos auto on ollut meillä, ja estää kaksi avointa kierrosta samalle autolle.
  Myydyn auton kortilla on painike "Auto palaa meille".
- **Kulut milloin tahansa.** Kulu kuuluu kierrokselle, ja sen voi kirjata myös myynnin jälkeen (esim. reklamaatio).
  Myyntipäivän jälkeiset kulut ovat *jälkikuluja*: kortti näyttää erikseen katteen myyntihetkellä ja lopullisen katteen.
- **Tilat:** Tarjottu → Ostettu → Tulossa → Kunnostuksessa → Myynnissä → Varattu → Myyty → Toimitettu, sekä Hylätty.
  Jokainen siirto tallentuu (kuka, milloin), joten vaihekohtaiset kestot näkyvät. Taaksepäin voi palauttaa virheen korjaamiseksi.
- **Tehtäväpohjat:** tilasiirto luo vaiheen vakiotehtävät automaattisesti henkilölle tai roolille. Pohjia muokataan Hallinnassa.
- **Kuntoraportti kahdesti:** myyjän ilmoittama (tarjous) ja oma saapumistarkastus, erot korostettuina.
  Lisäksi rengassarjat (1–n), vauriot kuvineen.
- **Kuvat:** ulko / sisä / vaurio / dokumentti, pääkuva, järjestys. Lataus suoraan puhelimen kamerasta. Kuvat pienennetään automaattisesti.
- **Varusteet:** ylläpidettävä katalogi kategorioittain, haku, "kopioi toisesta autosta". Käytössä olevaa varustetta ei poisteta vaan piilotetaan.
- **Muutosloki:** hintojen, tilojen, kulujen ja ajoneuvotietojen muutokset (kuka, milloin, vanha → uusi).
- **Multi-tenant valmiina:** jokaisella rivillä on `liike_id`.
- Rahat tallennetaan sentteinä (ei pyöristysvirheitä).

## Katelaskenta (`app/logiikka.py`)

- **Marginaaliverotus:** vero = (myyntihinta − ostohinta) × 25,5 / 125,5, jos voitto > 0. Kunnostuskulut eivät
  pienennä veron laskentaperustetta, mutta niiden ALV vähennetään, joten ne ovat katteessa verottomina.
  Kate = myyntihinta − vero − ostohinta − kulut (alv 0).
- **Normaali ALV:** kaikki verottomina. Kate = myynti − osto − kulut.
- ALV-kanta on liikkeen asetus (Hallinta → Asetukset).

Laskentasäännöt kannattaa vielä käydä läpi kirjanpitäjän silmin. Tämä versio laskee marginaaliveron autokohtaisesti.

## Seuraavat askeleet

1. **Kokeilu N247:n kanssa** ja palautteen perusteella korjaukset.
2. **Kuvat R2:een** ennen tuotantokäyttöä.
3. **Procountor-integraatio:** myyntilasku kaupasta, ostot ja kulut kirjanpitoon.
4. **Rekisterihaku** Traficomin sopimuskumppanin rajapinnan kautta: täyttää ajoneuvotiedot rekisterinumerolla.
   Käyttövoima-, vaihteisto- ja korimallikoodit on tehty vastaamaan Traficomin koodeja, mutta ne on tarkistettava
   Traficomin muuttujaluettelosta ennen kytkentää (osa koodeista, esim. hybridit, on omia).
5. **Hinta-arvio** omasta kauppadatasta: tarjous-, osto-, myynti- ja kiertoaikatiedot kertyvät jo nyt.

## Rakenne

```
app/
  __init__.py     sovelluksen luonti, pohjien apufunktiot
  schema.sql      tietomalli
  db.py           SQLite paikallisesti / PostgreSQL tuotannossa
  logiikka.py     tilat, siirrot, rahamuunnokset, katelaskenta
  auth.py         kirjautuminen, roolit, muutosloki
  autot.py        varastolista, uusi auto, auton kortti ja sen toiminnot
  tehtavat.py     etusivu, tehtävät, tehtäväpohjien käyttö
  hallinta.py     yritykset, käyttäjät, varustekatalogi, tehtäväpohjat, asetukset
  raportit.py     kate kk/kanava/toimittaja/ostaja, varaston ikä, saatavat
  storage.py      kuvien tallennus (vaihdetaan R2:een)
  seed.py         koodistot, varustekatalogi, tehtäväpohjat, demoaineisto
  templates/, static/style.css
wsgi.py
```
