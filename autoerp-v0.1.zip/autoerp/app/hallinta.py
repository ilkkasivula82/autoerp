"""Hallinta: yritykset (toimittajat/asiakkaat), käyttäjät, varustekatalogi,
tehtäväpohjat ja koodistot. Kaikki ylläpidettävissä ilman koodimuutoksia."""
from flask import Blueprint, abort, flash, g, redirect, render_template, request, url_for
from werkzeug.security import generate_password_hash

from .auth import liike_id, login_required, rooli_required
from .db import execute, insert, query
from .logiikka import TILAT, laske_kate

bp = Blueprint("hallinta", __name__, url_prefix="/hallinta")


def _txt(v):
    v = (v or "").strip()
    return v or None


# ---------- yritykset ----------

@bp.route("/yritykset", methods=["GET", "POST"])
@login_required
def yritykset():
    if request.method == "POST":
        f = request.form
        if not _txt(f.get("nimi")):
            flash("Nimi on pakollinen.", "virhe")
        else:
            arvot = dict(nimi=_txt(f.get("nimi")), y_tunnus=_txt(f.get("y_tunnus")), tyyppi=f.get("tyyppi") or "autoliike",
                         yhteyshenkilo=_txt(f.get("yhteyshenkilo")), puhelin=_txt(f.get("puhelin")),
                         sahkoposti=_txt(f.get("sahkoposti")), huomiot=_txt(f.get("huomiot")))
            yid = f.get("id")
            if yid:
                sets = ", ".join(f"{c} = ?" for c in arvot)
                execute(f"UPDATE yritys SET {sets} WHERE id = ? AND liike_id = ?", (*arvot.values(), int(yid), liike_id()))
            else:
                insert("yritys", liike_id=liike_id(), **arvot)
            flash("Yritys tallennettu.", "ok")
        return redirect(url_for("hallinta.yritykset"))

    rivit = query(
        """SELECT y.*,
             (SELECT COUNT(*) FROM kierto k WHERE k.toimittaja_id = y.id AND k.ostohinta IS NOT NULL) AS ostettu_n,
             (SELECT COUNT(*) FROM kierto k WHERE k.asiakas_id = y.id AND k.myyntihinta IS NOT NULL) AS myyty_n,
             (SELECT COUNT(*) FROM kierto k WHERE k.asiakas_id = y.id AND k.myyntihinta IS NOT NULL AND k.maksettu_pvm IS NULL) AS maksamatta_n
           FROM yritys y WHERE y.liike_id = ? ORDER BY y.nimi""", (liike_id(),))
    muokattava = None
    if request.args.get("muokkaa"):
        muokattava = query("SELECT * FROM yritys WHERE id = ? AND liike_id = ?", (int(request.args["muokkaa"]), liike_id()), one=True)
    return render_template("yritykset.html", rivit=rivit, m=muokattava or {})


@bp.route("/yritykset/<int:yid>")
@login_required
def yritys(yid):
    y = query("SELECT * FROM yritys WHERE id = ? AND liike_id = ?", (yid, liike_id()), one=True)
    if not y:
        abort(404)
    kaupat = query(
        """SELECT k.*, a.merkki, a.malli, a.rekisterinumero,
                  (SELECT COALESCE(SUM(summa_veroton),0) FROM kulu WHERE kulu.kierto_id = k.id) AS kulut,
                  CASE WHEN k.toimittaja_id = ? THEN 'osto' ELSE 'myynti' END AS suunta
           FROM kierto k JOIN ajoneuvo a ON a.id = k.ajoneuvo_id
           WHERE k.liike_id = ? AND (k.toimittaja_id = ? OR k.asiakas_id = ?) ORDER BY k.id DESC""",
        (yid, liike_id(), yid, yid))
    for r in kaupat:
        r["kate"] = laske_kate(r, r["kulut"], g.liike["alv_prosentti"])
    return render_template("yritys.html", y=y, kaupat=kaupat)


# ---------- käyttäjät ----------

@bp.route("/kayttajat", methods=["GET", "POST"])
@rooli_required("admin")
def kayttajat():
    if request.method == "POST":
        f = request.form
        kid = f.get("id")
        email = (f.get("sahkoposti") or "").strip().lower()
        if kid:
            execute("UPDATE kayttaja SET nimi = ?, rooli = ?, aktiivinen = ? WHERE id = ? AND liike_id = ?",
                    (f.get("nimi"), f.get("rooli"), 1 if f.get("aktiivinen") else 0, int(kid), liike_id()))
            if f.get("salasana"):
                execute("UPDATE kayttaja SET salasana_hash = ? WHERE id = ? AND liike_id = ?",
                        (generate_password_hash(f["salasana"]), int(kid), liike_id()))
            flash("Käyttäjä päivitetty.", "ok")
        else:
            if not (email and f.get("nimi") and f.get("salasana")):
                flash("Nimi, sähköposti ja salasana ovat pakollisia.", "virhe")
            elif query("SELECT id FROM kayttaja WHERE lower(sahkoposti) = ?", (email,), one=True):
                flash("Sähköposti on jo käytössä.", "virhe")
            else:
                insert("kayttaja", liike_id=liike_id(), sahkoposti=email, nimi=f["nimi"],
                       salasana_hash=generate_password_hash(f["salasana"]), rooli=f.get("rooli") or "myynti")
                flash("Käyttäjä lisätty.", "ok")
        return redirect(url_for("hallinta.kayttajat"))
    rivit = query("SELECT * FROM kayttaja WHERE liike_id = ? ORDER BY aktiivinen DESC, nimi", (liike_id(),))
    return render_template("kayttajat.html", rivit=rivit)


# ---------- varustekatalogi ----------

@bp.route("/varusteet", methods=["GET", "POST"])
@login_required
def varusteet():
    if request.method == "POST":
        f = request.form
        toiminto = f.get("toiminto")
        if toiminto == "kategoria" and _txt(f.get("nimi")):
            n = query("SELECT COALESCE(MAX(jarjestys),0) AS m FROM varustekategoria WHERE liike_id = ?", (liike_id(),), one=True)["m"]
            insert("varustekategoria", liike_id=liike_id(), nimi=_txt(f["nimi"]), jarjestys=(n or 0) + 1)
        elif toiminto == "varuste" and _txt(f.get("nimi")) and f.get("kategoria_id"):
            # useita kerralla: yksi per rivi
            for nimi in f["nimi"].splitlines():
                if nimi.strip():
                    insert("varuste", liike_id=liike_id(), kategoria_id=int(f["kategoria_id"]), nimi=nimi.strip())
        elif toiminto == "nakyvyys":
            execute("UPDATE varuste SET aktiivinen = 1 - aktiivinen WHERE id = ? AND liike_id = ?", (int(f["id"]), liike_id()))
        elif toiminto == "nimea":
            execute("UPDATE varuste SET nimi = ?, kategoria_id = ? WHERE id = ? AND liike_id = ?",
                    (_txt(f.get("nimi")), int(f["kategoria_id"]), int(f["id"]), liike_id()))
        return redirect(url_for("hallinta.varusteet"))
    kategoriat = query("SELECT * FROM varustekategoria WHERE liike_id = ? ORDER BY jarjestys, nimi", (liike_id(),))
    varusteet_ = query(
        """SELECT v.*, (SELECT COUNT(*) FROM ajoneuvo_varuste av WHERE av.varuste_id = v.id) AS kaytossa
           FROM varuste v WHERE v.liike_id = ? ORDER BY v.jarjestys, v.nimi""", (liike_id(),))
    return render_template("varusteet.html", kategoriat=kategoriat, varusteet=varusteet_)


# ---------- tehtäväpohjat ----------

@bp.route("/tehtavapohjat", methods=["GET", "POST"])
@login_required
def tehtavapohjat():
    if request.method == "POST":
        f = request.form
        if f.get("toiminto") == "poista":
            execute("DELETE FROM tehtavapohja WHERE id = ? AND liike_id = ?", (int(f["id"]), liike_id()))
        elif _txt(f.get("otsikko")) and f.get("tila"):
            vastuu = f.get("vastuu_id")
            ep = f.get("erapaiva_pv")
            insert("tehtavapohja", liike_id=liike_id(), tila=f["tila"], otsikko=_txt(f["otsikko"]),
                   rooli=_txt(f.get("rooli")), vastuu_id=int(vastuu) if vastuu else None,
                   erapaiva_pv=int(ep) if ep and ep.isdigit() else None)
        return redirect(url_for("hallinta.tehtavapohjat"))
    pohjat = query(
        """SELECT p.*, u.nimi AS vastuu_nimi FROM tehtavapohja p LEFT JOIN kayttaja u ON u.id = p.vastuu_id
           WHERE p.liike_id = ? ORDER BY p.jarjestys, p.id""", (liike_id(),))
    ryhmat = {t: [p for p in pohjat if p["tila"] == t] for t, _, _ in TILAT}
    kayttajat = query("SELECT id, nimi FROM kayttaja WHERE liike_id = ? AND aktiivinen = 1 ORDER BY nimi", (liike_id(),))
    return render_template("tehtavapohjat.html", ryhmat=ryhmat, kayttajat=kayttajat)


# ---------- koodistot ja asetukset ----------

@bp.route("/asetukset", methods=["GET", "POST"])
@rooli_required("admin")
def asetukset():
    if request.method == "POST":
        f = request.form
        if f.get("toiminto") == "liike":
            execute("UPDATE liike SET nimi = ?, y_tunnus = ?, alv_prosentti = ? WHERE id = ?",
                    (f.get("nimi"), _txt(f.get("y_tunnus")), float(f.get("alv_prosentti", "25.5").replace(",", ".")), liike_id()))
            flash("Asetukset tallennettu.", "ok")
        elif f.get("toiminto") == "koodi" and _txt(f.get("koodi")) and _txt(f.get("nimi")):
            if not query("SELECT id FROM koodi WHERE ryhma = ? AND koodi = ?", (f["ryhma"], f["koodi"].strip()), one=True):
                insert("koodi", ryhma=f["ryhma"], koodi=f["koodi"].strip(), nimi=f["nimi"].strip(), jarjestys=99)
        return redirect(url_for("hallinta.asetukset"))
    koodit = query("SELECT * FROM koodi ORDER BY ryhma, jarjestys, nimi")
    return render_template("asetukset.html", koodit=koodit)
