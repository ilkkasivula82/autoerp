-- AutoERP – tietomalli
-- Kirjoitettu SQLite-muodossa. db.py muuntaa sen PostgreSQL-muotoon
-- (AUTOINCREMENT -> SERIAL jne.), kun DATABASE_URL osoittaa Postgresiin.
-- Rahasummat tallennetaan SENTTEINÄ kokonaislukuina (ei pyöristysvirheitä).
-- Jokaisella liiketoimintarivillä on liike_id, jotta sama järjestelmä
-- palvelee myöhemmin useita autoliikkeitä (multi-tenant).

CREATE TABLE IF NOT EXISTS liike (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nimi TEXT NOT NULL,
    y_tunnus TEXT,
    alv_prosentti REAL NOT NULL DEFAULT 25.5,
    luotu TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS kayttaja (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    liike_id INTEGER NOT NULL REFERENCES liike(id),
    sahkoposti TEXT NOT NULL UNIQUE,
    nimi TEXT NOT NULL,
    salasana_hash TEXT NOT NULL,
    rooli TEXT NOT NULL DEFAULT 'myynti',   -- admin, osto, myynti, kunnostus, talous
    aktiivinen INTEGER NOT NULL DEFAULT 1,
    luotu TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Toimittajat ja asiakkaat samassa taulussa: sama liike voi olla kumpaakin.
CREATE TABLE IF NOT EXISTS yritys (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    liike_id INTEGER NOT NULL REFERENCES liike(id),
    nimi TEXT NOT NULL,
    y_tunnus TEXT,
    tyyppi TEXT NOT NULL DEFAULT 'autoliike', -- autoliike, rahoitusyhtio, huutokauppa, yksityinen, muu
    yhteyshenkilo TEXT,
    puhelin TEXT,
    sahkoposti TEXT,
    huomiot TEXT,
    luotu TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Koodistot (käyttövoima, vaihteisto, korimalli). Koodit kannattaa pitää
-- samoina kuin Traficomin datassa, jotta rekisterihaku täyttää ne suoraan.
CREATE TABLE IF NOT EXISTS koodi (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ryhma TEXT NOT NULL,        -- kayttovoima, vaihteisto, korimalli
    koodi TEXT NOT NULL,
    nimi TEXT NOT NULL,
    jarjestys INTEGER NOT NULL DEFAULT 0,
    UNIQUE (ryhma, koodi)
);

-- AJONEUVO = fyysinen auto. Sama ajoneuvo voi kulkea liikkeen läpi monta kertaa.
-- Tunnistus ensisijaisesti VIN:llä (rekisterinumero voi vaihtua, esim. erikoiskilpi).
CREATE TABLE IF NOT EXISTS ajoneuvo (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    liike_id INTEGER NOT NULL REFERENCES liike(id),
    rekisterinumero TEXT,
    vin TEXT,
    merkki TEXT NOT NULL,
    malli TEXT NOT NULL,
    mallitarkenne TEXT,
    vuosimalli INTEGER,
    ensirekisterointi TEXT,
    kayttovoima TEXT,           -- koodi.koodi (ryhma=kayttovoima)
    vaihteisto TEXT,            -- koodi.koodi (ryhma=vaihteisto)
    korimalli TEXT,             -- koodi.koodi (ryhma=korimalli)
    vari TEXT,
    teho_kw INTEGER,
    iskutilavuus INTEGER,
    vetotapa TEXT,
    ovet INTEGER,
    istuimet INTEGER,
    luotu TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS ix_ajoneuvo_rek ON ajoneuvo(liike_id, rekisterinumero);
CREATE INDEX IF NOT EXISTS ix_ajoneuvo_vin ON ajoneuvo(liike_id, vin);

-- KIERTO = yksi kierros liikkeen kautta: tarjous -> osto -> ... -> myynti -> toimitus.
-- Kaikki kauppaan liittyvä (hinnat, tila, km, kunto, kuvat, kulut, tehtävät) kuuluu kierrokselle.
-- Kun sama auto palaa vuoden päästä, sille avataan uusi kierto; vanhat säilyvät historiana.
CREATE TABLE IF NOT EXISTS kierto (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    liike_id INTEGER NOT NULL REFERENCES liike(id),
    ajoneuvo_id INTEGER NOT NULL REFERENCES ajoneuvo(id),
    km INTEGER,                 -- mittarilukema tällä kierroksella
    tila TEXT NOT NULL DEFAULT 'tarjottu',
    tila_muutettu TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    sijainti TEXT,

    -- Tarjous- ja ostotiedot
    toimittaja_id INTEGER REFERENCES yritys(id),
    ostokanava TEXT,            -- rahoitusyhtio, huutokauppa, autoliike, yksityinen, muu
    tarjottu_hinta INTEGER,     -- senttiä: myyjän pyytämä hinta tarjousvaiheessa
    tarjottu_pvm TEXT,
    hylkayksen_syy TEXT,
    ostohinta INTEGER,          -- senttiä. Marginaali: sellaisenaan. ALV: veroton.
    ostopvm TEXT,
    alv_kasittely TEXT NOT NULL DEFAULT 'marginaali', -- marginaali | alv
    arvioitu_saapuminen TEXT,

    -- Myyntitiedot
    pyyntihinta INTEGER,        -- senttiä: suunniteltu myyntihinta (arvioitua katetta varten)
    asiakas_id INTEGER REFERENCES yritys(id),
    myyntihinta INTEGER,        -- senttiä. Marginaali: verollinen. ALV: veroton.
    myyntipvm TEXT,
    laskunumero TEXT,
    maksettu_pvm TEXT,
    toimitettu_pvm TEXT,

    huomiot TEXT,
    luotu TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    luonut_id INTEGER REFERENCES kayttaja(id)
);
CREATE INDEX IF NOT EXISTS ix_kierto_liike_tila ON kierto(liike_id, tila);
CREATE INDEX IF NOT EXISTS ix_kierto_ajoneuvo ON kierto(ajoneuvo_id);

-- Jokainen tilasiirto: tästä lasketaan vaihekohtaiset seisonta-ajat.
CREATE TABLE IF NOT EXISTS tilahistoria (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    liike_id INTEGER NOT NULL REFERENCES liike(id),
    kierto_id INTEGER NOT NULL REFERENCES kierto(id),
    vanha_tila TEXT,
    uusi_tila TEXT NOT NULL,
    kayttaja_id INTEGER REFERENCES kayttaja(id),
    aika TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS kulu (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    liike_id INTEGER NOT NULL REFERENCES liike(id),
    kierto_id INTEGER NOT NULL REFERENCES kierto(id),
    tyyppi TEXT NOT NULL,       -- huutokauppamaksu, kuljetus, huolto, kunnostus, ..., reklamaatio
    -- Kulun voi kirjata milloin tahansa, myös myynnin jälkeen (esim. reklamaatio).
    -- Jälkikulu = kulu, jonka pvm on myyntipäivän jälkeen.
    kuvaus TEXT,
    summa_veroton INTEGER NOT NULL,  -- senttiä
    alv_prosentti REAL NOT NULL DEFAULT 25.5,
    pvm TEXT,
    toimittaja TEXT,
    luotu TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    luonut_id INTEGER REFERENCES kayttaja(id)
);

-- Kuntoraportti tehdään kahdesti: 'tarjous' (myyjän ilmoittama) ja 'saapuminen' (oma tarkastus).
CREATE TABLE IF NOT EXISTS kuntoraportti (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    liike_id INTEGER NOT NULL REFERENCES liike(id),
    kierto_id INTEGER NOT NULL REFERENCES kierto(id),
    vaihe TEXT NOT NULL,        -- tarjous | saapuminen
    tuulilasi TEXT,             -- ehja | kiveniskuja | vaihdettava
    avaimet INTEGER,
    maalipinta INTEGER,         -- 1-5
    yleiskunto INTEGER,         -- 1-5
    sisatilat INTEGER,          -- 1-5
    huoltokirja TEXT,           -- taysi | osittainen | puuttuu
    huomiot TEXT,
    tehnyt_id INTEGER REFERENCES kayttaja(id),
    paivitetty TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (kierto_id, vaihe)
);

CREATE TABLE IF NOT EXISTS rengassarja (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    liike_id INTEGER NOT NULL REFERENCES liike(id),
    kierto_id INTEGER NOT NULL REFERENCES kierto(id),
    tyyppi TEXT NOT NULL,       -- kesa | kitka | nasta | ymparivuotinen
    koko TEXT,
    vanteet TEXT,               -- pelti | alumiini
    urasyvyys_mm REAL,
    kunto INTEGER,              -- 1-5
    sijainti TEXT,              -- alla | mukana | varastossa
    huomiot TEXT
);

CREATE TABLE IF NOT EXISTS kuva (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    liike_id INTEGER NOT NULL REFERENCES liike(id),
    kierto_id INTEGER NOT NULL REFERENCES kierto(id),
    tiedosto TEXT NOT NULL,     -- tallennuspolku / R2-avain
    tyyppi TEXT NOT NULL DEFAULT 'ulko', -- ulko | sisa | vaurio | dokumentti
    jarjestys INTEGER NOT NULL DEFAULT 0,
    paakuva INTEGER NOT NULL DEFAULT 0,
    luotu TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    luonut_id INTEGER REFERENCES kayttaja(id)
);

CREATE TABLE IF NOT EXISTS vaurio (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    liike_id INTEGER NOT NULL REFERENCES liike(id),
    kierto_id INTEGER NOT NULL REFERENCES kierto(id),
    kohta TEXT NOT NULL,
    kuvaus TEXT,
    arvioitu_korjaus INTEGER,   -- senttiä
    kuva_id INTEGER REFERENCES kuva(id),
    korjattu INTEGER NOT NULL DEFAULT 0,
    luotu TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Varustekatalogi: ylläpidetään hallintasivulta. Varustetta ei poisteta, vaan piilotetaan.
CREATE TABLE IF NOT EXISTS varustekategoria (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    liike_id INTEGER NOT NULL REFERENCES liike(id),
    nimi TEXT NOT NULL,
    jarjestys INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS varuste (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    liike_id INTEGER NOT NULL REFERENCES liike(id),
    kategoria_id INTEGER NOT NULL REFERENCES varustekategoria(id),
    nimi TEXT NOT NULL,
    aktiivinen INTEGER NOT NULL DEFAULT 1,
    jarjestys INTEGER NOT NULL DEFAULT 0
);

-- Varusteet kuuluvat ajoneuvolle, joten ne säilyvät, kun auto palaa uudelle kierrokselle.
CREATE TABLE IF NOT EXISTS ajoneuvo_varuste (
    ajoneuvo_id INTEGER NOT NULL REFERENCES ajoneuvo(id),
    varuste_id INTEGER NOT NULL REFERENCES varuste(id),
    PRIMARY KEY (ajoneuvo_id, varuste_id)
);

-- Tehtäväpohjat: kun auto siirtyy tilaan, pohjat luovat sille tehtävät automaattisesti.
CREATE TABLE IF NOT EXISTS tehtavapohja (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    liike_id INTEGER NOT NULL REFERENCES liike(id),
    tila TEXT NOT NULL,
    otsikko TEXT NOT NULL,
    rooli TEXT,                 -- kenelle oletuksena (rooli)
    vastuu_id INTEGER REFERENCES kayttaja(id), -- tai tietylle henkilölle
    erapaiva_pv INTEGER,        -- eräpäivä N päivää tilasiirrosta
    jarjestys INTEGER NOT NULL DEFAULT 0,
    aktiivinen INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS tehtava (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    liike_id INTEGER NOT NULL REFERENCES liike(id),
    kierto_id INTEGER NOT NULL REFERENCES kierto(id),
    tila_vaihe TEXT,            -- missä vaiheessa tehtävä syntyi
    otsikko TEXT NOT NULL,
    kuvaus TEXT,
    vastuu_id INTEGER REFERENCES kayttaja(id),
    rooli TEXT,
    erapaiva TEXT,
    tehty INTEGER NOT NULL DEFAULT 0,
    tehty_aika TEXT,
    tehnyt_id INTEGER REFERENCES kayttaja(id),
    luotu TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    luonut_id INTEGER REFERENCES kayttaja(id)
);
CREATE INDEX IF NOT EXISTS ix_tehtava_vastuu ON tehtava(liike_id, vastuu_id, tehty);

-- Muutosloki: kuka muutti mitä ja milloin (hinnat, tilat, kaupat).
CREATE TABLE IF NOT EXISTS muutosloki (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    liike_id INTEGER NOT NULL REFERENCES liike(id),
    kayttaja_id INTEGER REFERENCES kayttaja(id),
    kohde TEXT NOT NULL,        -- esim. 'kierto', 'ajoneuvo'
    kohde_id INTEGER,
    kentta TEXT,
    vanha TEXT,
    uusi TEXT,
    aika TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS ix_loki_kohde ON muutosloki(kohde, kohde_id);
