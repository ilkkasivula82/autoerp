import os

from flask import Flask

from . import db, logiikka


def create_app(test_config=None):
    app = Flask(__name__, instance_relative_config=True)
    base = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    app.config.from_mapping(
        SECRET_KEY=os.environ.get("SECRET_KEY", "vaihda-tama-tuotannossa"),
        DATABASE_URL=os.environ.get("DATABASE_URL", ""),
        SQLITE_PATH=os.environ.get("SQLITE_PATH", os.path.join(base, "instance", "autoerp.sqlite")),
        UPLOAD_DIR=os.environ.get("UPLOAD_DIR", os.path.join(base, "uploads")),
        MAX_CONTENT_LENGTH=40 * 1024 * 1024,  # 40 Mt / lähetys (useita kuvia kerralla)
    )
    if test_config:
        app.config.update(test_config)

    db.init_app(app)

    from . import auth, autot, hallinta, raportit, tehtavat
    app.register_blueprint(auth.bp)
    app.register_blueprint(autot.bp)
    app.register_blueprint(tehtavat.bp)
    app.register_blueprint(hallinta.bp)
    app.register_blueprint(raportit.bp)
    app.add_url_rule("/", endpoint="index", view_func=tehtavat.etusivu)

    # Apufunktiot pohjiin
    app.jinja_env.globals.update(
        euro=logiikka.euro,
        euro_input=logiikka.euro_input,
        pvm=logiikka.pvm,
        paivia_sitten=logiikka.paivia_sitten,
        TILAT=logiikka.TILAT,
        TILA_NIMI=logiikka.TILA_NIMI,
        TILA_LUOKKA=logiikka.TILA_LUOKKA,
        OSTOKANAVAT=logiikka.OSTOKANAVAT,
        OSTOKANAVA_NIMI=dict(logiikka.OSTOKANAVAT),
        KULUTYYPIT=logiikka.KULUTYYPIT,
        KULUTYYPPI_NIMI=dict(logiikka.KULUTYYPIT),
        ROOLIT=logiikka.ROOLIT,
        ROOLI_NIMI=dict(logiikka.ROOLIT),
        ALV_KASITTELYT=logiikka.ALV_KASITTELYT,
        ALV_NIMI=dict(logiikka.ALV_KASITTELYT),
        YRITYSTYYPIT=logiikka.YRITYSTYYPIT,
    )

    @app.cli.command("init-db")
    def init_db_cmd():
        """Luo taulut ja esimerkkidatan."""
        from .seed import seed
        db.init_schema()
        seed()
        print("Tietokanta valmis.")

    return app
