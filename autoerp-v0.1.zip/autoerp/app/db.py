"""Tietokantakerros.

Paikallisesti käytetään SQLiteä (ei asennuksia). Tuotannossa (Render)
asetetaan DATABASE_URL=postgres://..., jolloin käytetään PostgreSQL:ää
psycopg-kirjaston kautta. Kyselyt kirjoitetaan '?'-paikkamerkeillä, ja
tämä moduuli muuntaa ne Postgresin '%s'-muotoon.
"""
import os
import re
import sqlite3

from flask import current_app, g

_PG = None


def _is_pg():
    url = current_app.config.get("DATABASE_URL") or ""
    return url.startswith("postgres")


def get_db():
    if "db" not in g:
        if _is_pg():
            import psycopg  # asennetaan tuotannossa: pip install "psycopg[binary]"
            from psycopg.rows import dict_row
            url = current_app.config["DATABASE_URL"].replace("postgres://", "postgresql://", 1)
            g.db = psycopg.connect(url, row_factory=dict_row)
        else:
            path = current_app.config["SQLITE_PATH"]
            os.makedirs(os.path.dirname(path), exist_ok=True)
            conn = sqlite3.connect(path)
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA foreign_keys = ON")
            g.db = conn
    return g.db


def close_db(_e=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def _sql(q):
    return q.replace("?", "%s") if _is_pg() else q


def query(q, args=(), one=False):
    cur = get_db().execute(_sql(q), args)
    rows = cur.fetchall()
    rows = [dict(r) for r in rows]
    return (rows[0] if rows else None) if one else rows


def execute(q, args=()):
    """Suorittaa muutoksen. Palauttaa uuden rivin id:n, jos kyselyssä on RETURNING id."""
    db = get_db()
    cur = db.execute(_sql(q), args)
    new_id = None
    if "RETURNING" in q.upper():
        row = cur.fetchone()
        new_id = row["id"] if row is not None else None
    db.commit()
    return new_id


def insert(table, **values):
    cols = ", ".join(values)
    marks = ", ".join("?" for _ in values)
    return execute(f"INSERT INTO {table} ({cols}) VALUES ({marks}) RETURNING id", tuple(values.values()))


def _pg_schema(sql):
    sql = re.sub(r"INTEGER PRIMARY KEY AUTOINCREMENT", "SERIAL PRIMARY KEY", sql)
    sql = sql.replace("TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP", "TEXT NOT NULL DEFAULT (to_char(now(), 'YYYY-MM-DD HH24:MI:SS'))")
    return sql


def init_schema():
    path = os.path.join(os.path.dirname(__file__), "schema.sql")
    with open(path, encoding="utf-8") as f:
        sql = f.read()
    db = get_db()
    if _is_pg():
        db.execute(_pg_schema(sql))
    else:
        db.executescript(sql)
    db.commit()


def init_app(app):
    app.teardown_appcontext(close_db)
