"""Tehtävät, tehtäväpohjat ja etusivu (omat tehtävät + tilannekuva)."""
from datetime import date, datetime, timedelta

from flask import Blueprint, abort, flash, g, redirect, render_template, request, url_for

from .auth import liike_id, login_required
from .db import execute, insert, query
from .logiikka import TILAT, VARASTOTILAT

bp = Blueprint("tehtavat", __name__)


def luo_tehtavat_tilalle(kierto_id, tila):
    """Luo tehtäväpohjien mukaiset tehtävät, kun kierto siirtyy tilaan."""
    pohjat = query(
        "SELECT * FROM tehtavapohja WHERE liike_id = ? AND tila = ? AND aktiivinen = 1 ORDER BY jarjestys, id",
        (liike_id(), tila),
    )
    for p in pohjat:
        erapaiva = None
        if p["erapaiva_pv"] is not None:
            erapaiva = (date.today() + timedelta(days=p["erapaiva_pv"])).isoformat()
        insert(
            "tehtava",
            liike_id=liike_id(),
            kierto_id=kierto_id,
            tila_vaihe=tila,
            otsikko=p["otsikko"],
            vastuu_id=p["vastuu_id"],
            rooli=p["rooli"],
            erapaiva=erapaiva,
            luonut_id=g.kayttaja["id"],
        )
    return len(pohjat)


def _omat_ehto():
    """Omat tehtävät: minulle nimetyt + nimeämättömät oman roolin tehtävät."""
    return "(t.vastuu_id = ? OR (t.vastuu_id IS NULL AND t.rooli = ?))", (g.kayttaja["id"], g.kayttaja["rooli"])


TEHTAVA_SELECT = """
    SELECT t.*, a.rekisterinumero, a.merkki, a.malli, k.tila AS kierto_tila,
           u.nimi AS vastuu_nimi
    FROM tehtava t
    JOIN kierto k ON k.id = t.kierto_id
    JOIN ajoneuvo a ON a.id = k.ajoneuvo_id
    LEFT JOIN kayttaja u ON u.id = t.vastuu_id
"""


@login_required
def etusivu():
    ehto, args = _omat_ehto()
    omat = query(
        TEHTAVA_SELECT + f" WHERE t.liike_id = ? AND t.tehty = 0 AND {ehto} "
        "ORDER BY CASE WHEN t.erapaiva IS NULL THEN 1 ELSE 0 END, t.erapaiva, t.id",
        (liike_id(), *args),
    )
    tilamaarat = {r["tila"]: r["n"] for r in query(
        "SELECT tila, COUNT(*) AS n FROM kierto WHERE liike_id = ? GROUP BY tila", (liike_id(),))}

    marks = ",".join("?" for _ in VARASTOTILAT)
    varasto = query(
        f"""SELECT k.id, k.ostohinta, k.ostopvm, k.tila, k.tila_muutettu, a.merkki, a.malli, a.rekisterinumero,
                   (SELECT COALESCE(SUM(summa_veroton),0) FROM kulu WHERE kulu.kierto_id = k.id) AS kulut
            FROM kierto k JOIN ajoneuvo a ON a.id = k.ajoneuvo_id
            WHERE k.liike_id = ? AND k.tila IN ({marks})""",
        (liike_id(), *VARASTOTILAT),
    )
    sidottu = sum((r["ostohinta"] or 0) + (r["kulut"] or 0) for r in varasto)
    from .logiikka import paivia_sitten
    for r in varasto:
        r["seisonut"] = paivia_sitten(r["ostopvm"]) or 0
    pisimmat = sorted(varasto, key=lambda r: -r["seisonut"])[:5]

    tanaan = date.today().isoformat()
    return render_template(
        "etusivu.html",
        omat=omat,
        tilamaarat=tilamaarat,
        varastossa=len(varasto),
        sidottu=sidottu,
        pisimmat=pisimmat,
        tanaan=tanaan,
    )


@bp.route("/tehtavat")
@login_required
def lista():
    nayta = request.args.get("nayta", "avoimet")
    kenelle = request.args.get("kenelle", "kaikki")
    ehdot = ["t.liike_id = ?"]
    args = [liike_id()]
    if nayta == "avoimet":
        ehdot.append("t.tehty = 0")
    elif nayta == "tehdyt":
        ehdot.append("t.tehty = 1")
    if kenelle == "omat":
        e, a = _omat_ehto()
        ehdot.append(e)
        args += a
    elif kenelle.isdigit():
        ehdot.append("t.vastuu_id = ?")
        args.append(int(kenelle))
    rivit = query(
        TEHTAVA_SELECT + " WHERE " + " AND ".join(ehdot) +
        " ORDER BY t.tehty, CASE WHEN t.erapaiva IS NULL THEN 1 ELSE 0 END, t.erapaiva, t.id DESC LIMIT 500",
        tuple(args),
    )
    kayttajat = query("SELECT id, nimi FROM kayttaja WHERE liike_id = ? AND aktiivinen = 1 ORDER BY nimi", (liike_id(),))
    return render_template("tehtavat.html", rivit=rivit, nayta=nayta, kenelle=kenelle,
                           kayttajat=kayttajat, tanaan=date.today().isoformat())


def _hae_tehtava(tid):
    t = query("SELECT * FROM tehtava WHERE id = ? AND liike_id = ?", (tid, liike_id()), one=True)
    if not t:
        abort(404)
    return t


@bp.route("/kierto/<int:kid>/tehtava", methods=["POST"])
@login_required
def lisaa(kid):
    k = query("SELECT id, tila FROM kierto WHERE id = ? AND liike_id = ?", (kid, liike_id()), one=True)
    if not k:
        abort(404)
    otsikko = request.form.get("otsikko", "").strip()
    if not otsikko:
        flash("Anna tehtävälle otsikko.", "virhe")
    else:
        vastuu = request.form.get("vastuu_id") or None
        insert(
            "tehtava",
            liike_id=liike_id(),
            kierto_id=kid,
            tila_vaihe=k["tila"],
            otsikko=otsikko,
            kuvaus=request.form.get("kuvaus") or None,
            vastuu_id=int(vastuu) if vastuu else None,
            erapaiva=request.form.get("erapaiva") or None,
            luonut_id=g.kayttaja["id"],
        )
    return redirect(url_for("autot.kortti", kid=kid, v="tehtavat"))


@bp.route("/tehtava/<int:tid>/kuittaa", methods=["POST"])
@login_required
def kuittaa(tid):
    t = _hae_tehtava(tid)
    if t["tehty"]:
        execute("UPDATE tehtava SET tehty = 0, tehty_aika = NULL, tehnyt_id = NULL WHERE id = ?", (tid,))
    else:
        execute("UPDATE tehtava SET tehty = 1, tehty_aika = ?, tehnyt_id = ? WHERE id = ?",
                (datetime.now().isoformat(timespec="seconds"), g.kayttaja["id"], tid))
    return redirect(request.form.get("takaisin") or url_for("autot.kortti", kid=t["kierto_id"], v="tehtavat"))


@bp.route("/tehtava/<int:tid>/poista", methods=["POST"])
@login_required
def poista(tid):
    t = _hae_tehtava(tid)
    execute("DELETE FROM tehtava WHERE id = ?", (tid,))
    return redirect(url_for("autot.kortti", kid=t["kierto_id"], v="tehtavat"))
