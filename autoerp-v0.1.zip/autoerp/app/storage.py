"""Kuvien tallennus.

Nyt tiedostot tallennetaan paikalliseen kansioon (UPLOAD_DIR). Tuotannossa
tämän moduulin voi vaihtaa Cloudflare R2:een samaan tapaan kuin
tositesovelluksessa: vain tallenna/avaa/poista-funktiot muuttuvat, muu
sovellus käyttää pelkkää avainta (kuva.tiedosto).
"""
import io
import os
import uuid

from flask import current_app
from PIL import Image, ImageOps

MAX_KOKO = 2000     # pidemmän sivun pikselit täysikokoisessa kuvassa
PIKKU_KOKO = 480    # listanäkymän pikkukuva


def _polku(avain):
    base = current_app.config["UPLOAD_DIR"]
    polku = os.path.abspath(os.path.join(base, avain))
    if not polku.startswith(os.path.abspath(base) + os.sep):
        raise ValueError("Virheellinen polku")
    return polku


def tallenna_kuva(tiedosto, liike_id, kierto_id):
    """Pienentää, kääntää EXIF:n mukaan ja tallentaa JPEG:nä. Palauttaa avaimen."""
    img = Image.open(tiedosto.stream)
    img = ImageOps.exif_transpose(img).convert("RGB")
    avain = f"{liike_id}/{kierto_id}/{uuid.uuid4().hex}.jpg"

    iso = img.copy()
    iso.thumbnail((MAX_KOKO, MAX_KOKO))
    _kirjoita(avain, iso, 85)

    pieni = img.copy()
    pieni.thumbnail((PIKKU_KOKO, PIKKU_KOKO))
    _kirjoita(pikkukuva_avain(avain), pieni, 80)
    return avain


def pikkukuva_avain(avain):
    return avain[:-4] + "_t.jpg"


def _kirjoita(avain, img, laatu):
    polku = _polku(avain)
    os.makedirs(os.path.dirname(polku), exist_ok=True)
    buf = io.BytesIO()
    img.save(buf, "JPEG", quality=laatu, optimize=True)
    with open(polku, "wb") as f:
        f.write(buf.getvalue())


def tiedostopolku(avain):
    return _polku(avain)


def poista(avain):
    for a in (avain, pikkukuva_avain(avain)):
        try:
            os.remove(_polku(a))
        except (FileNotFoundError, ValueError):
            pass
