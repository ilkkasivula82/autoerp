"""Kirjautuminen, käyttäjäistunto, roolitarkistus ja muutosloki."""
import functools

from flask import Blueprint, abort, flash, g, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash

from .db import insert, query

bp = Blueprint("auth", __name__)


@bp.before_app_request
def lataa_kayttaja():
    uid = session.get("kayttaja_id")
    g.kayttaja = None
    g.liike = None
    if uid:
        k = query("SELECT * FROM kayttaja WHERE id = ? AND aktiivinen = 1", (uid,), one=True)
        if k:
            g.kayttaja = k
            g.liike = query("SELECT * FROM liike WHERE id = ?", (k["liike_id"],), one=True)
        else:
            session.clear()


def login_required(view):
    @functools.wraps(view)
    def wrapped(**kwargs):
        if g.kayttaja is None:
            return redirect(url_for("auth.kirjaudu", seuraava=request.path))
        return view(**kwargs)
    return wrapped


def rooli_required(*roolit):
    """Esim. @rooli_required('admin'). Admin pääsee aina."""
    def deco(view):
        @functools.wraps(view)
        @login_required
        def wrapped(**kwargs):
            if g.kayttaja["rooli"] != "admin" and g.kayttaja["rooli"] not in roolit:
                abort(403)
            return view(**kwargs)
        return wrapped
    return deco


def liike_id():
    return g.kayttaja["liike_id"]


def kirjaa(kohde, kohde_id, kentta, vanha, uusi):
    """Kirjaa muutoksen muutoslokiin, jos arvo oikeasti muuttui."""
    if (vanha if vanha not in ("", None) else None) == (uusi if uusi not in ("", None) else None):
        return
    insert(
        "muutosloki",
        liike_id=liike_id(),
        kayttaja_id=g.kayttaja["id"],
        kohde=kohde,
        kohde_id=kohde_id,
        kentta=kentta,
        vanha=None if vanha is None else str(vanha),
        uusi=None if uusi is None else str(uusi),
    )


@bp.route("/kirjaudu", methods=["GET", "POST"])
def kirjaudu():
    if request.method == "POST":
        email = request.form.get("sahkoposti", "").strip().lower()
        k = query("SELECT * FROM kayttaja WHERE lower(sahkoposti) = ? AND aktiivinen = 1", (email,), one=True)
        if k and check_password_hash(k["salasana_hash"], request.form.get("salasana", "")):
            session.clear()
            session["kayttaja_id"] = k["id"]
            seuraava = request.args.get("seuraava") or url_for("index")
            if not seuraava.startswith("/"):
                seuraava = url_for("index")
            return redirect(seuraava)
        flash("Väärä sähköposti tai salasana.", "virhe")
    return render_template("kirjaudu.html")


@bp.route("/kirjaudu-ulos")
def kirjaudu_ulos():
    session.clear()
    return redirect(url_for("auth.kirjaudu"))
