"""Autot: varastolista, uusi auto / tarjous, auton kortti ja sen toiminnot.

Käsitteet:
  ajoneuvo = fyysinen auto (VIN, rekisteri, tekniset tiedot, varusteet)
  kierto   = yksi kierros liikkeen kautta (hinnat, tila, km, kunto, kuvat, kulut, tehtävät)
URL /autot/<kid> osoittaa aina kiertoon.
"""
from datetime import date

from flask import (Blueprint, abort, flash, g, jsonify, redirect, render_template,
                   request, send_file, url_for)

from . import storage
from .auth import kirjaa, liike_id, login_required
from .db import execute, insert, query
from .logiikka import (SIIRROT, TILA_NIMI, VARASTOTILAT, euro, euro_senteiksi,
                       laske_kate, paivia_sitten)
from .tehtavat import luo_tehtavat_tilalle

bp = Blueprint("autot", __name__)

PAATTYNEET = ("myyty", "toimitettu", "hylatty")


# ---------- apufunktiot ----------

def _int(v):
    try:
        return int(str(v).replace(" ", "").replace(" ", "")) if v not in (None, "") else None
    except ValueError:
        return None


def _txt(v):
    v = (v or "").strip()
    return v or None


def _rek(v):
    """Normalisoi rekisterinumeron: 'abc123' / 'ABC 123' -> 'ABC-123'."""
    import re
    v = (v or "").strip().upper().replace(" ", "")
    m = re.fullmatch(r"([A-ZÅÄÖ]{1,3})-?(\d{1,3})", v)
    if m:
        v = f"{m.group(1)}-{m.group(2)}"
    return v or None


# kenttä -> muunnin
AJONEUVO_KENTAT = {
    "rekisterinumero": _rek, "vin": lambda v: (_txt(v) or "").upper() or None,
    "merkki": _txt, "malli": _txt, "mallitarkenne": _txt, "vuosimalli": _int,
    "ensirekisterointi": _txt, "kayttovoima": _txt, "vaihteisto": _txt, "korimalli": _txt,
    "vari": _txt, "teho_kw": _int, "iskutilavuus": _int, "vetotapa": _txt, "ovet": _int, "istuimet": _int,
}
KAUPPA_KENTAT = {
    "km": _int, "sijainti": _txt, "toimittaja_id": _int, "ostokanava": _txt,
    "tarjottu_hinta": euro_senteiksi, "tarjottu_pvm": _txt, "ostohinta": euro_senteiksi, "ostopvm": _txt,
    "alv_kasittely": _txt, "arvioitu_saapuminen": _txt, "pyyntihinta": euro_senteiksi,
    "asiakas_id": _int, "myyntihinta": euro_senteiksi, "myyntipvm": _txt, "laskunumero": _txt,
    "maksettu_pvm": _txt, "toimitettu_pvm": _txt, "hylkayksen_syy": _txt, "huomiot": _txt,
}
RAHAKENTAT = {"tarjottu_hinta", "ostohinta", "pyyntihinta", "myyntihinta"}


def hae_kierto(kid):
    k = query(
        """SELECT k.*, a.rekisterinumero, a.vin, a.merkki, a.malli, a.mallitarkenne, a.vuosimalli,
                  a.ensirekisterointi, a.kayttovoima, a.vaihteisto, a.korimalli, a.vari, a.teho_kw,
                  a.iskutilavuus, a.vetotapa, a.ovet, a.istuimet,
                  t.nimi AS toimittaja_nimi, s.nimi AS asiakas_nimi
           FROM kierto k
           JOIN ajoneuvo a ON a.id = k.ajoneuvo_id
           LEFT JOIN yritys t ON t.id = k.toimittaja_id
           LEFT JOIN yritys s ON s.id = k.asiakas_id
           WHERE k.id = ? AND k.liike_id = ?""",
        (kid, liike_id()), one=True)
    if not k:
        abort(404)
    return k


def kulusummat(kierto):
    kulut = query("SELECT summa_veroton, pvm FROM kulu WHERE kierto_id = ?", (kierto["id"],))
    yht = sum(r["summa_veroton"] for r in kulut)
    jalki = 0
    if kierto.get("myyntipvm"):
        jalki = sum(r["summa_veroton"] for r in kulut if r["pvm"] and r["pvm"] > kierto["myyntipvm"])
    return yht, jalki


def etsi_ajoneuvo(vin, rek):
    """Etsii aiemmin kirjatun ajoneuvon. VIN ensin, koska rekisterinumero voi vaihtua."""
    if vin:
        a = query("SELECT * FROM ajoneuvo WHERE liike_id = ? AND upper(vin) = ?", (liike_id(), vin.upper()), one=True)
        if a:
            return a
    if rek:
        return query("SELECT * FROM ajoneuvo WHERE liike_id = ? AND replace(upper(rekisterinumero), '-', '') = ? ORDER BY id DESC",
                     (liike_id(), rek.upper().replace("-", "")), one=True)
    return None


def aiemmat_kierrot(ajoneuvo_id, paitsi=None):
    return query(
        """SELECT k.id, k.tila, k.km, k.ostopvm, k.ostohinta, k.myyntipvm, k.myyntihinta, k.tarjottu_pvm, k.luotu,
                  t.nimi AS toimittaja_nimi, s.nimi AS asiakas_nimi
           FROM kierto k LEFT JOIN yritys t ON t.id = k.toimittaja_id LEFT JOIN yritys s ON s.id = k.asiakas_id
           WHERE k.ajoneuvo_id = ? AND k.liike_id = ? AND k.id != ? ORDER BY k.id DESC""",
        (ajoneuvo_id, liike_id(), paitsi or 0))


def yritykset():
    return query("SELECT id, nimi, tyyppi FROM yritys WHERE liike_id = ? ORDER BY nimi", (liike_id(),))


def koodit():
    rivit = query("SELECT * FROM koodi ORDER BY ryhma, jarjestys, nimi")
    out = {}
    for r in rivit:
        out.setdefault(r["ryhma"], []).append(r)
    return out


def koodinimet():
    return {(r["ryhma"], r["koodi"]): r["nimi"] for r in query("SELECT * FROM koodi")}


# ---------- varastolista ----------

NAKYMAT = {
    "varasto": ("Varasto", VARASTOTILAT),
    "tarjotut": ("Tarjotut", ["tarjottu"]),
    "myydyt": ("Myydyt", ["myyty", "toimitettu"]),
    "hylatyt": ("Hylätyt", ["hylatty"]),
    "kaikki": ("Kaikki", None),
}


@bp.route("/autot")
@login_required
def lista():
    nakyma = request.args.get("n", "varasto")
    if nakyma not in NAKYMAT:
        nakyma = "varasto"
    tila = request.args.get("tila") or None
    haku = (request.args.get("q") or "").strip()

    ehdot = ["k.liike_id = ?"]
    args = [liike_id()]
    tilat = [tila] if tila else NAKYMAT[nakyma][1]
    if tilat:
        ehdot.append("k.tila IN (" + ",".join("?" for _ in tilat) + ")")
        args += tilat
    if haku:
        ehdot.append("(upper(a.rekisterinumero) LIKE ? OR upper(a.vin) LIKE ? OR upper(a.merkki || ' ' || a.malli) LIKE ?)")
        h = f"%{haku.upper()}%"
        args += [h, h, h]

    rivit = query(
        f"""SELECT k.*, a.rekisterinumero, a.merkki, a.malli, a.mallitarkenne, a.vuosimalli,
                   a.kayttovoima, a.vaihteisto,
                   (SELECT COALESCE(SUM(summa_veroton),0) FROM kulu WHERE kulu.kierto_id = k.id) AS kulut,
                   (SELECT COUNT(*) FROM tehtava WHERE tehtava.kierto_id = k.id AND tehty = 0) AS avoimet,
                   (SELECT id FROM kuva WHERE kuva.kierto_id = k.id AND kuva.tyyppi != 'dokumentti' ORDER BY paakuva DESC, jarjestys, id LIMIT 1) AS kuva_id,
                   (SELECT COUNT(*) FROM kierto k2 WHERE k2.ajoneuvo_id = k.ajoneuvo_id) AS kierroksia,
                   t.nimi AS toimittaja_nimi, s.nimi AS asiakas_nimi
            FROM kierto k
            JOIN ajoneuvo a ON a.id = k.ajoneuvo_id
            LEFT JOIN yritys t ON t.id = k.toimittaja_id
            LEFT JOIN yritys s ON s.id = k.asiakas_id
            WHERE {' AND '.join(ehdot)}
            ORDER BY k.tila_muutettu DESC, k.id DESC""",
        tuple(args))

    alv = g.liike["alv_prosentti"]
    yht = {"osto": 0, "kulut": 0, "kate": 0, "kate_n": 0}
    for r in rivit:
        r["kate"] = laske_kate(r, r["kulut"], alv)
        r["tilassa"] = paivia_sitten(r["tila_muutettu"])
        r["varastossa"] = paivia_sitten(r["ostopvm"]) if r["tila"] in VARASTOTILAT else None
        yht["osto"] += r["ostohinta"] or 0
        yht["kulut"] += r["kulut"] or 0
        if r["kate"]:
            yht["kate"] += r["kate"]["kate"]
            yht["kate_n"] += 1

    return render_template("autot.html", rivit=rivit, nakyma=nakyma, NAKYMAT=NAKYMAT, tila=tila,
                           haku=haku, yht=yht, koodinimet=koodinimet())


# ---------- uusi auto / tarjous ----------

@bp.route("/autot/tarkista")
@login_required
def tarkista():
    """Lomake kysyy tätä, kun rekisteri tai VIN on syötetty: onko auto ollut meillä ennen?"""
    a = etsi_ajoneuvo(_txt(request.args.get("vin")), _rek(request.args.get("rek")))
    if not a:
        return jsonify({"loytyi": False})
    kierrot = aiemmat_kierrot(a["id"])
    aktiivinen = next((k for k in kierrot if k["tila"] not in PAATTYNEET), None)
    return jsonify({
        "loytyi": True,
        "ajoneuvo": {k: a[k] for k in ("id", "rekisterinumero", "vin", "merkki", "malli", "mallitarkenne",
                                        "vuosimalli", "kayttovoima", "vaihteisto", "korimalli", "vari")},
        "kierrot": [{"id": k["id"], "tila": TILA_NIMI.get(k["tila"], k["tila"]),
                     "myyntipvm": k["myyntipvm"], "asiakas": k["asiakas_nimi"],
                     "myyntihinta": euro(k["myyntihinta"]) if k["myyntihinta"] else None,
                     "url": url_for("autot.kortti", kid=k["id"])} for k in kierrot],
        "aktiivinen_url": url_for("autot.kortti", kid=aktiivinen["id"]) if aktiivinen else None,
    })


@bp.route("/autot/uusi", methods=["GET", "POST"])
@login_required
def uusi():
    if request.method == "POST":
        f = request.form
        vin = AJONEUVO_KENTAT["vin"](f.get("vin"))
        rek = _rek(f.get("rekisterinumero"))
        if not (_txt(f.get("merkki")) and _txt(f.get("malli"))):
            flash("Merkki ja malli ovat pakollisia.", "virhe")
            return render_template("auto_uusi.html", f=f, yritykset=yritykset(), koodit=koodit())

        a = etsi_ajoneuvo(vin, rek)
        if a:
            aktiivinen = query(
                f"SELECT id FROM kierto WHERE ajoneuvo_id = ? AND tila NOT IN ({','.join('?' for _ in PAATTYNEET)})",
                (a["id"], *PAATTYNEET), one=True)
            if aktiivinen:
                flash("Tämä auto on jo järjestelmässä avoimena. Avattiin olemassa oleva kortti.", "virhe")
                return redirect(url_for("autot.kortti", kid=aktiivinen["id"]))
            ajoneuvo_id = a["id"]
            # Päivitä tunnisteet / puuttuvat tiedot, jos ne on annettu
            for kentta, muunna in AJONEUVO_KENTAT.items():
                uusi_arvo = muunna(f.get(kentta))
                if uusi_arvo is not None and uusi_arvo != a[kentta]:
                    kirjaa("ajoneuvo", ajoneuvo_id, kentta, a[kentta], uusi_arvo)
                    execute(f"UPDATE ajoneuvo SET {kentta} = ? WHERE id = ?", (uusi_arvo, ajoneuvo_id))
            palaava = True
        else:
            arvot = {k: m(f.get(k)) for k, m in AJONEUVO_KENTAT.items()}
            ajoneuvo_id = insert("ajoneuvo", liike_id=liike_id(), **arvot)
            palaava = False

        tila = "ostettu" if f.get("heti_ostettu") else "tarjottu"
        kid = insert(
            "kierto",
            liike_id=liike_id(),
            ajoneuvo_id=ajoneuvo_id,
            km=_int(f.get("km")),
            tila=tila,
            toimittaja_id=_int(f.get("toimittaja_id")),
            ostokanava=_txt(f.get("ostokanava")),
            tarjottu_hinta=euro_senteiksi(f.get("tarjottu_hinta")),
            tarjottu_pvm=date.today().isoformat(),
            ostohinta=euro_senteiksi(f.get("ostohinta")) if tila == "ostettu" else None,
            ostopvm=date.today().isoformat() if tila == "ostettu" else None,
            alv_kasittely=f.get("alv_kasittely") or "marginaali",
            huomiot=_txt(f.get("huomiot")),
            luonut_id=g.kayttaja["id"],
        )
        insert("tilahistoria", liike_id=liike_id(), kierto_id=kid, vanha_tila=None, uusi_tila=tila,
               kayttaja_id=g.kayttaja["id"])
        luo_tehtavat_tilalle(kid, tila)
        if palaava:
            flash("Auto on ollut meillä aiemmin. Sille avattiin uusi kierros, ja aiemmat kierrokset näkyvät Historia-välilehdellä.", "ok")
        else:
            flash("Auto lisätty.", "ok")
        return redirect(url_for("autot.kortti", kid=kid))
    return render_template("auto_uusi.html", f={}, yritykset=yritykset(), koodit=koodit())


# ---------- auton kortti ----------

@bp.route("/autot/<int:kid>")
@login_required
def kortti(kid):
    k = hae_kierto(kid)
    kulut = query("SELECT * FROM kulu WHERE kierto_id = ? ORDER BY pvm, id", (kid,))
    kulut_yht, jalki = kulusummat(k)
    alv = g.liike["alv_prosentti"]
    kate = laske_kate(k, kulut_yht, alv, jalkikulut=jalki)

    raportit = {r["vaihe"]: r for r in query("SELECT * FROM kuntoraportti WHERE kierto_id = ?", (kid,))}
    renkaat = query("SELECT * FROM rengassarja WHERE kierto_id = ? ORDER BY id", (kid,))
    vauriot = query("SELECT * FROM vaurio WHERE kierto_id = ? ORDER BY korjattu, id", (kid,))
    kuvat = query("SELECT * FROM kuva WHERE kierto_id = ? ORDER BY paakuva DESC, tyyppi, jarjestys, id", (kid,))

    kategoriat = query("SELECT * FROM varustekategoria WHERE liike_id = ? ORDER BY jarjestys, nimi", (liike_id(),))
    varusteet = query("SELECT * FROM varuste WHERE liike_id = ? ORDER BY jarjestys, nimi", (liike_id(),))
    valitut = {r["varuste_id"] for r in query("SELECT varuste_id FROM ajoneuvo_varuste WHERE ajoneuvo_id = ?", (k["ajoneuvo_id"],))}

    tehtavat = query(
        """SELECT t.*, u.nimi AS vastuu_nimi, d.nimi AS tehnyt_nimi FROM tehtava t
           LEFT JOIN kayttaja u ON u.id = t.vastuu_id LEFT JOIN kayttaja d ON d.id = t.tehnyt_id
           WHERE t.kierto_id = ? ORDER BY t.tehty, CASE WHEN t.erapaiva IS NULL THEN 1 ELSE 0 END, t.erapaiva, t.id""",
        (kid,))
    kayttajat = query("SELECT id, nimi, rooli FROM kayttaja WHERE liike_id = ? AND aktiivinen = 1 ORDER BY nimi", (liike_id(),))

    historia = query(
        """SELECT h.*, u.nimi AS kayttaja_nimi FROM tilahistoria h LEFT JOIN kayttaja u ON u.id = h.kayttaja_id
           WHERE h.kierto_id = ? ORDER BY h.id""", (kid,))
    # vaihekohtaiset kestot
    for i, h in enumerate(historia):
        loppu = historia[i + 1]["aika"] if i + 1 < len(historia) else None
        alku_pv = paivia_sitten(h["aika"]) or 0
        loppu_pv = paivia_sitten(loppu) if loppu else 0
        h["kesto"] = alku_pv - (loppu_pv or 0)
    loki = query(
        """SELECT l.*, u.nimi AS kayttaja_nimi FROM muutosloki l LEFT JOIN kayttaja u ON u.id = l.kayttaja_id
           WHERE (l.kohde = 'kierto' AND l.kohde_id = ?) OR (l.kohde = 'ajoneuvo' AND l.kohde_id = ?)
           ORDER BY l.id DESC LIMIT 200""", (kid, k["ajoneuvo_id"]))
    aiemmat = aiemmat_kierrot(k["ajoneuvo_id"], paitsi=kid)
    muut_kierrot = query(
        """SELECT k.id, a.merkki, a.malli, a.rekisterinumero FROM kierto k JOIN ajoneuvo a ON a.id = k.ajoneuvo_id
           WHERE k.liike_id = ? AND k.ajoneuvo_id != ? AND upper(a.merkki) = upper(?) ORDER BY k.id DESC LIMIT 30""",
        (liike_id(), k["ajoneuvo_id"], k["merkki"]))

    return render_template(
        "auto_kortti.html", k=k, kulut=kulut, kulut_yht=kulut_yht, jalki=jalki, kate=kate,
        raportit=raportit, renkaat=renkaat, vauriot=vauriot, kuvat=kuvat,
        kategoriat=kategoriat, varusteet=varusteet, valitut=valitut,
        tehtavat=tehtavat, kayttajat=kayttajat, historia=historia, loki=loki, aiemmat=aiemmat,
        muut_kierrot=muut_kierrot, siirrot=SIIRROT.get(k["tila"], []), yritykset=yritykset(),
        koodit=koodit(), koodinimet=koodinimet(), valilehti=request.args.get("v", "yhteenveto"),
        tanaan=date.today().isoformat(), PAATTYNEET=PAATTYNEET,
    )


# ---------- tilasiirto ----------

@bp.route("/autot/<int:kid>/tila", methods=["POST"])
@login_required
def vaihda_tila(kid):
    k = hae_kierto(kid)
    uusi = request.form.get("tila")
    if uusi not in SIIRROT.get(k["tila"], []):
        flash("Tilasiirto ei ole sallittu.", "virhe")
        return redirect(url_for("autot.kortti", kid=kid))

    f = request.form
    paivitys = {}
    tanaan = date.today().isoformat()
    if uusi == "ostettu":
        hinta = euro_senteiksi(f.get("ostohinta")) or k["ostohinta"]
        if hinta is None:
            flash("Anna ostohinta, kun merkitset auton ostetuksi.", "virhe")
            return redirect(url_for("autot.kortti", kid=kid))
        paivitys.update(ostohinta=hinta, ostopvm=_txt(f.get("ostopvm")) or k["ostopvm"] or tanaan,
                        alv_kasittely=f.get("alv_kasittely") or k["alv_kasittely"])
    elif uusi == "hylatty":
        paivitys["hylkayksen_syy"] = _txt(f.get("hylkayksen_syy"))
    elif uusi in ("varattu", "myyty"):
        asiakas = _int(f.get("asiakas_id")) or k["asiakas_id"]
        paivitys["asiakas_id"] = asiakas
        if uusi == "myyty":
            hinta = euro_senteiksi(f.get("myyntihinta")) or k["myyntihinta"]
            if hinta is None or asiakas is None:
                flash("Anna ostaja ja myyntihinta, kun merkitset auton myydyksi.", "virhe")
                return redirect(url_for("autot.kortti", kid=kid))
            paivitys.update(myyntihinta=hinta, myyntipvm=_txt(f.get("myyntipvm")) or k["myyntipvm"] or tanaan,
                            laskunumero=_txt(f.get("laskunumero")) or k["laskunumero"])
    elif uusi == "toimitettu":
        paivitys["toimitettu_pvm"] = _txt(f.get("toimitettu_pvm")) or tanaan

    for kentta, arvo in paivitys.items():
        if arvo != k.get(kentta):
            kirjaa("kierto", kid, kentta, k.get(kentta), arvo)
            execute(f"UPDATE kierto SET {kentta} = ? WHERE id = ?", (arvo, kid))

    execute("UPDATE kierto SET tila = ?, tila_muutettu = CURRENT_TIMESTAMP WHERE id = ?", (uusi, kid))
    insert("tilahistoria", liike_id=liike_id(), kierto_id=kid, vanha_tila=k["tila"], uusi_tila=uusi,
           kayttaja_id=g.kayttaja["id"])
    kirjaa("kierto", kid, "tila", TILA_NIMI[k["tila"]], TILA_NIMI[uusi])
    n = luo_tehtavat_tilalle(kid, uusi)
    viesti = f"Tila: {TILA_NIMI[uusi]}."
    if n:
        viesti += f" Luotiin {n} tehtävää."
    flash(viesti, "ok")
    return redirect(url_for("autot.kortti", kid=kid))


@bp.route("/autot/<int:kid>/palaa", methods=["POST"])
@login_required
def palaa(kid):
    """Sama ajoneuvo tulee takaisin: avataan uusi kierto samalle ajoneuvolle."""
    k = hae_kierto(kid)
    avoin = query(
        f"SELECT id FROM kierto WHERE ajoneuvo_id = ? AND tila NOT IN ({','.join('?' for _ in PAATTYNEET)})",
        (k["ajoneuvo_id"], *PAATTYNEET), one=True)
    if avoin:
        flash("Autolla on jo avoin kierros.", "virhe")
        return redirect(url_for("autot.kortti", kid=avoin["id"]))
    uusi_id = insert("kierto", liike_id=liike_id(), ajoneuvo_id=k["ajoneuvo_id"], tila="tarjottu",
                     tarjottu_pvm=date.today().isoformat(), alv_kasittely=k["alv_kasittely"],
                     luonut_id=g.kayttaja["id"])
    insert("tilahistoria", liike_id=liike_id(), kierto_id=uusi_id, vanha_tila=None, uusi_tila="tarjottu",
           kayttaja_id=g.kayttaja["id"])
    luo_tehtavat_tilalle(uusi_id, "tarjottu")
    flash("Uusi kierros avattu. Päivitä kilometrit, toimittaja ja kunto. Varusteet siirtyivät automaattisesti.", "ok")
    return redirect(url_for("autot.kortti", kid=uusi_id, v="kauppa"))


# ---------- tietojen muokkaus ----------

@bp.route("/autot/<int:kid>/ajoneuvo", methods=["POST"])
@login_required
def tallenna_ajoneuvo(kid):
    k = hae_kierto(kid)
    for kentta, muunna in AJONEUVO_KENTAT.items():
        if kentta not in request.form:
            continue
        arvo = muunna(request.form.get(kentta))
        if kentta in ("merkki", "malli") and not arvo:
            continue
        if arvo != k[kentta]:
            kirjaa("ajoneuvo", k["ajoneuvo_id"], kentta, k[kentta], arvo)
            execute(f"UPDATE ajoneuvo SET {kentta} = ? WHERE id = ?", (arvo, k["ajoneuvo_id"]))
    flash("Ajoneuvon tiedot tallennettu.", "ok")
    return redirect(url_for("autot.kortti", kid=kid, v="perustiedot"))


@bp.route("/autot/<int:kid>/kauppa", methods=["POST"])
@login_required
def tallenna_kauppa(kid):
    k = hae_kierto(kid)
    for kentta, muunna in KAUPPA_KENTAT.items():
        if kentta not in request.form:
            continue
        arvo = muunna(request.form.get(kentta))
        if kentta == "alv_kasittely" and not arvo:
            continue
        if arvo != k[kentta]:
            vanha, uusi_n = k[kentta], arvo
            if kentta in RAHAKENTAT:
                vanha, uusi_n = (euro(vanha) if vanha is not None else None), (euro(arvo) if arvo is not None else None)
            kirjaa("kierto", kid, kentta, vanha, uusi_n)
            execute(f"UPDATE kierto SET {kentta} = ? WHERE id = ?", (arvo, kid))
    flash("Tiedot tallennettu.", "ok")
    return redirect(url_for("autot.kortti", kid=kid, v=request.form.get("v", "kauppa")))


# ---------- kulut ----------

@bp.route("/autot/<int:kid>/kulu", methods=["POST"])
@login_required
def lisaa_kulu(kid):
    k = hae_kierto(kid)
    f = request.form
    summa = euro_senteiksi(f.get("summa"))
    if summa is None:
        flash("Anna kulun summa.", "virhe")
        return redirect(url_for("autot.kortti", kid=kid, v="kulut"))
    alv = float((f.get("alv_prosentti") or str(g.liike["alv_prosentti"])).replace(",", "."))
    if f.get("summa_on") == "verollinen":
        summa = int(round(summa / (1 + alv / 100)))
    pvm_ = _txt(f.get("pvm")) or date.today().isoformat()
    insert("kulu", liike_id=liike_id(), kierto_id=kid, tyyppi=f.get("tyyppi") or "muu",
           kuvaus=_txt(f.get("kuvaus")), summa_veroton=summa, alv_prosentti=alv, pvm=pvm_,
           toimittaja=_txt(f.get("toimittaja")), luonut_id=g.kayttaja["id"])
    kirjaa("kierto", kid, "kulu lisätty", None, f"{f.get('tyyppi')}: {euro(summa, True)} alv 0 %")
    if k["myyntipvm"] and pvm_ > k["myyntipvm"]:
        flash("Jälkikulu kirjattu. Se pienentää auton lopullista katetta.", "ok")
    return redirect(url_for("autot.kortti", kid=kid, v="kulut"))


@bp.route("/autot/<int:kid>/kulu/<int:kulu_id>/poista", methods=["POST"])
@login_required
def poista_kulu(kid, kulu_id):
    hae_kierto(kid)
    r = query("SELECT * FROM kulu WHERE id = ? AND kierto_id = ?", (kulu_id, kid), one=True)
    if r:
        execute("DELETE FROM kulu WHERE id = ?", (kulu_id,))
        kirjaa("kierto", kid, "kulu poistettu", f"{r['tyyppi']}: {euro(r['summa_veroton'], True)}", None)
    return redirect(url_for("autot.kortti", kid=kid, v="kulut"))


# ---------- kunto ----------

@bp.route("/autot/<int:kid>/kunto/<vaihe>", methods=["POST"])
@login_required
def tallenna_kunto(kid, vaihe):
    hae_kierto(kid)
    if vaihe not in ("tarjous", "saapuminen"):
        abort(404)
    f = request.form
    arvot = dict(tuulilasi=_txt(f.get("tuulilasi")), avaimet=_int(f.get("avaimet")),
                 maalipinta=_int(f.get("maalipinta")), yleiskunto=_int(f.get("yleiskunto")),
                 sisatilat=_int(f.get("sisatilat")), huoltokirja=_txt(f.get("huoltokirja")),
                 huomiot=_txt(f.get("huomiot")))
    vanha = query("SELECT id FROM kuntoraportti WHERE kierto_id = ? AND vaihe = ?", (kid, vaihe), one=True)
    if vanha:
        sets = ", ".join(f"{c} = ?" for c in arvot)
        execute(f"UPDATE kuntoraportti SET {sets}, tehnyt_id = ?, paivitetty = CURRENT_TIMESTAMP WHERE id = ?",
                (*arvot.values(), g.kayttaja["id"], vanha["id"]))
    else:
        insert("kuntoraportti", liike_id=liike_id(), kierto_id=kid, vaihe=vaihe, tehnyt_id=g.kayttaja["id"], **arvot)
    flash("Kuntotiedot tallennettu.", "ok")
    return redirect(url_for("autot.kortti", kid=kid, v="kunto"))


@bp.route("/autot/<int:kid>/rengas", methods=["POST"])
@login_required
def lisaa_rengas(kid):
    hae_kierto(kid)
    f = request.form
    ura = f.get("urasyvyys_mm", "").replace(",", ".")
    insert("rengassarja", liike_id=liike_id(), kierto_id=kid, tyyppi=f.get("tyyppi") or "kesa",
           koko=_txt(f.get("koko")), vanteet=_txt(f.get("vanteet")),
           urasyvyys_mm=float(ura) if ura.strip() else None, kunto=_int(f.get("kunto")),
           sijainti=_txt(f.get("sijainti")), huomiot=_txt(f.get("huomiot")))
    return redirect(url_for("autot.kortti", kid=kid, v="kunto"))


@bp.route("/autot/<int:kid>/rengas/<int:rid>/poista", methods=["POST"])
@login_required
def poista_rengas(kid, rid):
    hae_kierto(kid)
    execute("DELETE FROM rengassarja WHERE id = ? AND kierto_id = ?", (rid, kid))
    return redirect(url_for("autot.kortti", kid=kid, v="kunto"))


@bp.route("/autot/<int:kid>/vaurio", methods=["POST"])
@login_required
def lisaa_vaurio(kid):
    hae_kierto(kid)
    f = request.form
    kuva_id = None
    tiedosto = request.files.get("kuva")
    if tiedosto and tiedosto.filename:
        avain = storage.tallenna_kuva(tiedosto, liike_id(), kid)
        kuva_id = insert("kuva", liike_id=liike_id(), kierto_id=kid, tiedosto=avain, tyyppi="vaurio",
                         luonut_id=g.kayttaja["id"])
    insert("vaurio", liike_id=liike_id(), kierto_id=kid, kohta=_txt(f.get("kohta")) or "Muu",
           kuvaus=_txt(f.get("kuvaus")), arvioitu_korjaus=euro_senteiksi(f.get("arvioitu_korjaus")), kuva_id=kuva_id)
    return redirect(url_for("autot.kortti", kid=kid, v="kunto"))


@bp.route("/autot/<int:kid>/vaurio/<int:vid>/korjattu", methods=["POST"])
@login_required
def vaurio_korjattu(kid, vid):
    hae_kierto(kid)
    execute("UPDATE vaurio SET korjattu = 1 - korjattu WHERE id = ? AND kierto_id = ?", (vid, kid))
    return redirect(url_for("autot.kortti", kid=kid, v="kunto"))


# ---------- kuvat ----------

@bp.route("/autot/<int:kid>/kuvat", methods=["POST"])
@login_required
def lataa_kuvat(kid):
    hae_kierto(kid)
    tyyppi = request.form.get("tyyppi") or "ulko"
    onko_paakuva = query("SELECT id FROM kuva WHERE kierto_id = ? AND paakuva = 1", (kid,), one=True)
    seuraava = (query("SELECT COALESCE(MAX(jarjestys),0) AS m FROM kuva WHERE kierto_id = ?", (kid,), one=True)["m"] or 0) + 1
    n = 0
    for tiedosto in request.files.getlist("kuvat"):
        if not tiedosto or not tiedosto.filename:
            continue
        try:
            avain = storage.tallenna_kuva(tiedosto, liike_id(), kid)
        except Exception:
            flash(f"Kuvaa {tiedosto.filename} ei voitu lukea.", "virhe")
            continue
        paa = 1 if (not onko_paakuva and n == 0 and tyyppi == "ulko") else 0
        insert("kuva", liike_id=liike_id(), kierto_id=kid, tiedosto=avain, tyyppi=tyyppi,
               jarjestys=seuraava + n, paakuva=paa, luonut_id=g.kayttaja["id"])
        n += 1
    if n:
        flash(f"{n} kuvaa lisätty.", "ok")
    return redirect(url_for("autot.kortti", kid=kid, v="kuvat"))


def _hae_kuva(kuva_id):
    r = query("SELECT * FROM kuva WHERE id = ? AND liike_id = ?", (kuva_id, liike_id()), one=True)
    if not r:
        abort(404)
    return r


@bp.route("/kuva/<int:kuva_id>")
@bp.route("/kuva/<int:kuva_id>/<koko>")
@login_required
def nayta_kuva(kuva_id, koko="iso"):
    r = _hae_kuva(kuva_id)
    avain = storage.pikkukuva_avain(r["tiedosto"]) if koko == "pieni" else r["tiedosto"]
    try:
        return send_file(storage.tiedostopolku(avain), mimetype="image/jpeg", max_age=86400)
    except FileNotFoundError:
        abort(404)


@bp.route("/kuva/<int:kuva_id>/paakuva", methods=["POST"])
@login_required
def aseta_paakuva(kuva_id):
    r = _hae_kuva(kuva_id)
    execute("UPDATE kuva SET paakuva = 0 WHERE kierto_id = ?", (r["kierto_id"],))
    execute("UPDATE kuva SET paakuva = 1 WHERE id = ?", (kuva_id,))
    return redirect(url_for("autot.kortti", kid=r["kierto_id"], v="kuvat"))


@bp.route("/kuva/<int:kuva_id>/tyyppi", methods=["POST"])
@login_required
def vaihda_kuvatyyppi(kuva_id):
    r = _hae_kuva(kuva_id)
    t = request.form.get("tyyppi")
    if t in ("ulko", "sisa", "vaurio", "dokumentti"):
        execute("UPDATE kuva SET tyyppi = ? WHERE id = ?", (t, kuva_id))
    return redirect(url_for("autot.kortti", kid=r["kierto_id"], v="kuvat"))


@bp.route("/kuva/<int:kuva_id>/siirra/<suunta>", methods=["POST"])
@login_required
def siirra_kuva(kuva_id, suunta):
    r = _hae_kuva(kuva_id)
    kuvat = query("SELECT id, jarjestys FROM kuva WHERE kierto_id = ? AND tyyppi = ? ORDER BY jarjestys, id",
                  (r["kierto_id"], r["tyyppi"]))
    ids = [k["id"] for k in kuvat]
    i = ids.index(kuva_id)
    j = i - 1 if suunta == "ylos" else i + 1
    if 0 <= j < len(ids):
        ids[i], ids[j] = ids[j], ids[i]
        for n, x in enumerate(ids):
            execute("UPDATE kuva SET jarjestys = ? WHERE id = ?", (n + 1, x))
    return redirect(url_for("autot.kortti", kid=r["kierto_id"], v="kuvat"))


@bp.route("/kuva/<int:kuva_id>/poista", methods=["POST"])
@login_required
def poista_kuva(kuva_id):
    r = _hae_kuva(kuva_id)
    execute("UPDATE vaurio SET kuva_id = NULL WHERE kuva_id = ?", (kuva_id,))
    execute("DELETE FROM kuva WHERE id = ?", (kuva_id,))
    storage.poista(r["tiedosto"])
    return redirect(url_for("autot.kortti", kid=r["kierto_id"], v="kuvat"))


# ---------- varusteet ----------

@bp.route("/autot/<int:kid>/varusteet", methods=["POST"])
@login_required
def tallenna_varusteet(kid):
    k = hae_kierto(kid)
    valitut = {int(x) for x in request.form.getlist("varuste") if x.isdigit()}
    sallitut = {r["id"] for r in query("SELECT id FROM varuste WHERE liike_id = ?", (liike_id(),))}
    valitut &= sallitut
    execute("DELETE FROM ajoneuvo_varuste WHERE ajoneuvo_id = ?", (k["ajoneuvo_id"],))
    for v in valitut:
        execute("INSERT INTO ajoneuvo_varuste (ajoneuvo_id, varuste_id) VALUES (?, ?)", (k["ajoneuvo_id"], v))
    flash(f"Varusteet tallennettu ({len(valitut)} kpl).", "ok")
    return redirect(url_for("autot.kortti", kid=kid, v="varusteet"))


@bp.route("/autot/<int:kid>/varusteet/kopioi", methods=["POST"])
@login_required
def kopioi_varusteet(kid):
    k = hae_kierto(kid)
    lahde = hae_kierto(_int(request.form.get("lahde")) or 0)
    execute(
        """INSERT INTO ajoneuvo_varuste (ajoneuvo_id, varuste_id)
           SELECT ?, varuste_id FROM ajoneuvo_varuste WHERE ajoneuvo_id = ?
           AND varuste_id NOT IN (SELECT varuste_id FROM ajoneuvo_varuste WHERE ajoneuvo_id = ?)""",
        (k["ajoneuvo_id"], lahde["ajoneuvo_id"], k["ajoneuvo_id"]))
    flash(f"Varusteet kopioitu autosta {lahde['merkki']} {lahde['malli']} {lahde['rekisterinumero'] or ''}. Tarkista ja tallenna.", "ok")
    return redirect(url_for("autot.kortti", kid=kid, v="varusteet"))
