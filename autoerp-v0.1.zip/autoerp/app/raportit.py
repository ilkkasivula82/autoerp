"""Raportit: kate kuukausittain / ostokanavittain / toimittajittain, varaston ikä, myyntisaatavat."""
from datetime import date

from flask import Blueprint, g, render_template, request

from .auth import liike_id, login_required
from .db import query
from .logiikka import VARASTOTILAT, laske_kate, paivia_sitten

bp = Blueprint("raportit", __name__, url_prefix="/raportit")


def _myydyt(alku, loppu):
    rivit = query(
        """SELECT k.*, a.merkki, a.malli, a.rekisterinumero, t.nimi AS toimittaja_nimi, s.nimi AS asiakas_nimi
           FROM kierto k JOIN ajoneuvo a ON a.id = k.ajoneuvo_id
           LEFT JOIN yritys t ON t.id = k.toimittaja_id LEFT JOIN yritys s ON s.id = k.asiakas_id
           WHERE k.liike_id = ? AND k.myyntihinta IS NOT NULL AND k.myyntipvm >= ? AND k.myyntipvm <= ?
           ORDER BY k.myyntipvm""", (liike_id(), alku, loppu))
    alv = g.liike["alv_prosentti"]
    for r in rivit:
        kulut = query("SELECT summa_veroton, pvm FROM kulu WHERE kierto_id = ?", (r["id"],))
        yht = sum(x["summa_veroton"] for x in kulut)
        jalki = sum(x["summa_veroton"] for x in kulut if x["pvm"] and x["pvm"] > r["myyntipvm"])
        r["kate"] = laske_kate(r, yht, alv, jalkikulut=jalki)
        r["kiertoaika"] = None
        if r["ostopvm"]:
            r["kiertoaika"] = (date.fromisoformat(r["myyntipvm"][:10]) - date.fromisoformat(r["ostopvm"][:10])).days
    return rivit


def _ryhmittele(rivit, avain):
    out = {}
    for r in rivit:
        k = avain(r) or "–"
        o = out.setdefault(k, {"n": 0, "myynti": 0, "kate": 0, "jalki": 0, "paivat": [], "rivit": []})
        o["n"] += 1
        o["myynti"] += r["kate"]["nettomyynti"]
        o["kate"] += r["kate"]["kate"]
        o["jalki"] += r["kate"]["jalkikulut"]
        if r["kiertoaika"] is not None:
            o["paivat"].append(r["kiertoaika"])
    for o in out.values():
        o["ka_kate"] = o["kate"] / o["n"] if o["n"] else 0
        o["ka_paivat"] = sum(o["paivat"]) / len(o["paivat"]) if o["paivat"] else None
        o["kate_per_pv"] = (o["kate"] / sum(o["paivat"])) if o["paivat"] and sum(o["paivat"]) else None
    return out


@bp.route("/")
@login_required
def index():
    t = date.today()
    alku = request.args.get("alku") or date(t.year, 1, 1).isoformat()
    loppu = request.args.get("loppu") or t.isoformat()
    rivit = _myydyt(alku, loppu)
    kk = _ryhmittele(rivit, lambda r: r["myyntipvm"][:7])
    kanava = _ryhmittele(rivit, lambda r: r["ostokanava"])
    toimittaja = _ryhmittele(rivit, lambda r: r["toimittaja_nimi"])
    asiakas = _ryhmittele(rivit, lambda r: r["asiakas_nimi"])
    yht = _ryhmittele(rivit, lambda r: "yht").get("yht")

    marks = ",".join("?" for _ in VARASTOTILAT)
    varasto = query(
        f"""SELECT k.*, a.merkki, a.malli, a.rekisterinumero,
                   (SELECT COALESCE(SUM(summa_veroton),0) FROM kulu WHERE kulu.kierto_id = k.id) AS kulut
            FROM kierto k JOIN ajoneuvo a ON a.id = k.ajoneuvo_id
            WHERE k.liike_id = ? AND k.tila IN ({marks})""", (liike_id(), *VARASTOTILAT))
    ikaluokat = [("0–30 pv", 0, 30), ("31–60 pv", 31, 60), ("61–90 pv", 61, 90), ("yli 90 pv", 91, 10**6)]
    ika = []
    for nimi, a, b in ikaluokat:
        ryhma = [r for r in varasto if a <= (paivia_sitten(r["ostopvm"]) or 0) <= b]
        ika.append({"nimi": nimi, "n": len(ryhma),
                    "sidottu": sum((r["ostohinta"] or 0) + (r["kulut"] or 0) for r in ryhma)})

    saatavat = query(
        """SELECT k.id, k.myyntihinta, k.myyntipvm, k.laskunumero, k.alv_kasittely, a.merkki, a.malli, a.rekisterinumero,
                  s.nimi AS asiakas_nimi
           FROM kierto k JOIN ajoneuvo a ON a.id = k.ajoneuvo_id LEFT JOIN yritys s ON s.id = k.asiakas_id
           WHERE k.liike_id = ? AND k.myyntihinta IS NOT NULL AND k.maksettu_pvm IS NULL ORDER BY k.myyntipvm""",
        (liike_id(),))
    for s in saatavat:
        s["ika"] = paivia_sitten(s["myyntipvm"])
        r = g.liike["alv_prosentti"] / 100
        s["verollinen"] = int(round(s["myyntihinta"] * (1 + r))) if s["alv_kasittely"] == "alv" else s["myyntihinta"]

    return render_template("raportit.html", alku=alku, loppu=loppu, rivit=rivit, kk=kk, kanava=kanava,
                           toimittaja=toimittaja, asiakas=asiakas, yht=yht, ika=ika, saatavat=saatavat)
