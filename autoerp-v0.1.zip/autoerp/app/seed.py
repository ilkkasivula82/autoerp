"""Perusdata (koodistot, varustekatalogi, tehtäväpohjat) ja demoaineisto.

Koodit on valittu vastaamaan Traficomin avoimen datan koodeja siltä osin kuin
mahdollista. Ne kannattaa tarkistaa Traficomin aineistokuvauksesta
(Ajoneuvojen avoin data, muuttujaluettelo) ennen rekisterihaun kytkemistä.
"""
import os
from datetime import date, timedelta

from werkzeug.security import generate_password_hash

from .db import execute, insert, query

KOODIT = {
    "kayttovoima": [
        ("01", "Bensiini"), ("02", "Diesel"), ("04", "Sähkö"),
        ("HB", "Hybridi (bensiini)"), ("HD", "Hybridi (diesel)"),
        ("PHB", "Ladattava hybridi (bensiini)"), ("PHD", "Ladattava hybridi (diesel)"),
        ("06", "Kaasu (CNG/LPG)"), ("E85", "Etanoli / Flex"),
    ],
    "vaihteisto": [("1", "Manuaali"), ("2", "Automaatti"), ("3", "Portaaton (CVT)"), ("4", "Puoliautomaatti / DSG")],
    "korimalli": [
        ("AA", "Sedan"), ("AB", "Viistoperä"), ("AC", "Farmari"), ("AD", "Coupé"), ("AE", "Avoauto"),
        ("AF", "Tila-auto / monikäyttö"), ("SUV", "Maastoauto / SUV"), ("PA", "Pakettiauto"), ("LAVA", "Avolava"),
    ],
}

VARUSTEET = {
    "Turvallisuus": ["Mukautuva vakionopeudensäädin", "Kaistavahti", "Kuolleen kulman varoitin", "Hätäjarrutusavustin",
                     "Liikennemerkkien tunnistus", "Väsymysvaroitin", "ISOFIX-kiinnikkeet"],
    "Pysäköinti": ["Pysäköintitutka edessä", "Pysäköintitutka takana", "Peruutuskamera", "360° kamera",
                   "Pysäköintiavustin"],
    "Mukavuus": ["Ilmastointi", "Automaattinen ilmastointi", "2-alueinen ilmastointi", "Istuinlämmitys edessä",
                 "Istuinlämmitys takana", "Ohjauspyörän lämmitys", "Tuulilasin lämmitys", "Sähkösäätöiset etuistuimet",
                 "Muistipenkit", "Nahkaverhoilu", "Avaimeton käynnistys", "Avaimeton lukitus", "Sähkötoiminen takaluukku",
                 "Panoraamakatto", "Kattoluukku"],
    "Lämmitys": ["Webasto / polttoainekäyttöinen lisälämmitin", "Moottorinlämmitin", "Sisähaaran pistoke",
                 "Etäkäynnistys sovelluksella"],
    "Multimedia": ["Navigaattori", "Apple CarPlay", "Android Auto", "Bluetooth", "Premium-äänentoisto",
                   "Digitaalinen mittaristo", "Tuulilasinäyttö (HUD)", "Langaton lataus"],
    "Valot": ["LED-ajovalot", "Matriisi-LED-valot", "Xenon-ajovalot", "Lisävalot", "Kaarrevalot"],
    "Muut": ["Vetokoukku", "Sähköinen vetokoukku", "Kattokaiteet", "Neliveto", "Ilmajousitus", "Talvirenkaat vanteilla",
             "Huoltokirja", "Sähköinen huoltokirja", "Tummennetut takalasit"],
}

TEHTAVAPOHJAT = [
    # (tila, otsikko, rooli, eräpäivä pv)
    ("tarjottu", "Arvioi hinta ja tee ostopäätös", "osto", 1),
    ("tarjottu", "Pyydä kuvat ja huoltohistoria myyjältä", "osto", 1),
    ("ostettu", "Maksa ostolasku", "talous", 3),
    ("ostettu", "Tilaa kuljetus", "osto", 2),
    ("tulossa", "Varmista paperit ja avaimet", "osto", None),
    ("tulossa", "Tee saapumistarkastus ja kuntoraportti", "kunnostus", None),
    ("kunnostuksessa", "Pesu ja preppaus", "kunnostus", 3),
    ("kunnostuksessa", "Tarkista huoltotarve", "kunnostus", 2),
    ("myynnissa", "Ota myyntikuvat", "myynti", 1),
    ("myynnissa", "Aseta pyyntihinta", "myynti", 1),
    ("myyty", "Laadi kauppakirja ja lasku", "talous", 1),
    ("myyty", "Tee omistajanvaihdos", "myynti", 2),
    ("toimitettu", "Varmista maksu saapunut", "talous", 7),
]


def seed(demo=None):
    if demo is None:
        demo = os.environ.get("SEED_DEMO", "1") == "1"

    if not query("SELECT id FROM koodi LIMIT 1"):
        for ryhma, rivit in KOODIT.items():
            for i, (koodi, nimi) in enumerate(rivit):
                insert("koodi", ryhma=ryhma, koodi=koodi, nimi=nimi, jarjestys=i)

    if query("SELECT id FROM liike LIMIT 1"):
        return
    lid = insert("liike", nimi="N247 Finland Oy", y_tunnus=None, alv_prosentti=25.5)

    for i, (kat, rivit) in enumerate(VARUSTEET.items()):
        kid = insert("varustekategoria", liike_id=lid, nimi=kat, jarjestys=i)
        for j, v in enumerate(rivit):
            insert("varuste", liike_id=lid, kategoria_id=kid, nimi=v, jarjestys=j)

    for i, (tila, otsikko, rooli, ep) in enumerate(TEHTAVAPOHJAT):
        insert("tehtavapohja", liike_id=lid, tila=tila, otsikko=otsikko, rooli=rooli, erapaiva_pv=ep, jarjestys=i)

    salasana = os.environ.get("ADMIN_SALASANA", "vaihda-heti")
    admin = insert("kayttaja", liike_id=lid, sahkoposti=os.environ.get("ADMIN_EMAIL", "admin@n247.fi"),
                   nimi="Ylläpitäjä", salasana_hash=generate_password_hash(salasana), rooli="admin")
    if demo:
        _demo(lid, admin)


def _demo(lid, admin):
    """Esimerkkiautoja kokeilua varten. Poista tuotannosta: SEED_DEMO=0."""
    h = generate_password_hash("demo")
    ostaja = insert("kayttaja", liike_id=lid, sahkoposti="osto@n247.fi", nimi="Olli Ostaja", salasana_hash=h, rooli="osto")
    insert("kayttaja", liike_id=lid, sahkoposti="myynti@n247.fi", nimi="Maija Myyjä", salasana_hash=h, rooli="myynti")
    insert("kayttaja", liike_id=lid, sahkoposti="piha@n247.fi", nimi="Pekka Piha", salasana_hash=h, rooli="kunnostus")

    Y = {}
    for nimi, tyyppi in [("Esimerkki Rahoitus Oy", "rahoitusyhtio"), ("Huutokauppa Esimerkki", "huutokauppa"),
                         ("Autotalo Mallinen Oy", "autoliike"), ("Vaihtoauto Testilä Oy", "autoliike"),
                         ("Autokeskus Demo Oy", "autoliike")]:
        Y[nimi] = insert("yritys", liike_id=lid, nimi=nimi, tyyppi=tyyppi)

    t = date.today()

    def d(n):
        return (t - timedelta(days=n)).isoformat()

    def auto(rek, vin, merkki, malli, tark, vm, kv, vt, kori, km, tila, toim, kanava, osto, ostopv,
             pyynti=None, asiakas=None, myynti=None, myyntipv=None, maksettu=False, alv="marginaali", tarjottu=None):
        aid = insert("ajoneuvo", liike_id=lid, rekisterinumero=rek, vin=vin, merkki=merkki, malli=malli,
                     mallitarkenne=tark, vuosimalli=vm, kayttovoima=kv, vaihteisto=vt, korimalli=kori)
        return kierros(aid, km, tila, toim, kanava, osto, ostopv, pyynti, asiakas, myynti, myyntipv, maksettu, alv, tarjottu)

    def kierros(aid, km, tila, toim, kanava, osto, ostopv, pyynti=None, asiakas=None, myynti=None,
                myyntipv=None, maksettu=False, alv="marginaali", tarjottu=None):
        kid = insert("kierto", liike_id=lid, ajoneuvo_id=aid, km=km, tila=tila, toimittaja_id=Y[toim],
                     ostokanava=kanava, tarjottu_hinta=tarjottu, tarjottu_pvm=d((ostopv or 0) + 2),
                     ostohinta=osto, ostopvm=d(ostopv) if ostopv is not None else None, alv_kasittely=alv,
                     pyyntihinta=pyynti, asiakas_id=Y[asiakas] if asiakas else None, myyntihinta=myynti,
                     myyntipvm=d(myyntipv) if myyntipv is not None else None,
                     maksettu_pvm=d(max((myyntipv or 0) - 5, 0)) if maksettu else None,
                     luonut_id=admin)
        muutos = d(myyntipv if myyntipv is not None else (ostopv if ostopv is not None else 1))
        execute("UPDATE kierto SET tila_muutettu = ? WHERE id = ?", (muutos, kid))
        insert("tilahistoria", liike_id=lid, kierto_id=kid, uusi_tila="tarjottu", kayttaja_id=ostaja)
        execute("UPDATE tilahistoria SET aika = ? WHERE kierto_id = ?", (d((ostopv or 0) + 2), kid))
        if tila != "tarjottu":
            insert("tilahistoria", liike_id=lid, kierto_id=kid, vanha_tila="tarjottu", uusi_tila=tila, kayttaja_id=ostaja)
            execute("UPDATE tilahistoria SET aika = ? WHERE kierto_id = ? AND uusi_tila = ?", (muutos, kid, tila))
        return kid

    def kulu(kid, tyyppi, summa, pv, kuvaus=None):
        insert("kulu", liike_id=lid, kierto_id=kid, tyyppi=tyyppi, summa_veroton=summa, pvm=d(pv), kuvaus=kuvaus)

    k1 = auto("ABC-123", "WVWZZZAUZKW000001", "Volkswagen", "Golf", "1.5 TSI Style", 2019, "01", "4", "AB",
              98000, "myynnissa", "Esimerkki Rahoitus Oy", "rahoitusyhtio", 1290000, 24, pyynti=1490000)
    kulu(k1, "kuljetus", 18000, 22); kulu(k1, "pesu", 9000, 20); kulu(k1, "huolto", 42000, 19, "Määräaikaishuolto")

    k2 = auto("XYZ-987", "YV1ZWA8UDL1000002", "Volvo", "XC60", "T8 Inscription", 2020, "PHB", "2", "SUV",
              124000, "kunnostuksessa", "Huutokauppa Esimerkki", "huutokauppa", 2750000, 9, pyynti=3190000)
    kulu(k2, "huutokauppamaksu", 35000, 9); kulu(k2, "kuljetus", 22000, 7)

    auto("KLM-456", "WBA8E1100JA000003", "BMW", "320d", "xDrive Touring", 2018, "02", "2", "AC",
         156000, "tulossa", "Autotalo Mallinen Oy", "autoliike", 1680000, 2, pyynti=1950000)

    auto("TRE-321", "JTDKBRFU0K3000004", "Toyota", "RAV4", "2.5 Hybrid AWD", 2019, "HB", "3", "SUV",
         87000, "tarjottu", "Esimerkki Rahoitus Oy", "rahoitusyhtio", None, None, tarjottu=2450000)
    auto("SKO-555", "TMBJJ7NE5L0000005", "Skoda", "Octavia", "2.0 TDI Combi", 2020, "02", "4", "AC",
         143000, "tarjottu", "Huutokauppa Esimerkki", "huutokauppa", None, None, tarjottu=1390000)

    k6 = auto("MER-777", "WDD2130041A000006", "Mercedes-Benz", "E 220 d", "4Matic", 2019, "02", "2", "AA",
              112000, "myyty", "Esimerkki Rahoitus Oy", "rahoitusyhtio", 2390000, 48,
              pyynti=2790000, asiakas="Vaihtoauto Testilä Oy", myynti=2690000, myyntipv=12)
    kulu(k6, "kuljetus", 20000, 46); kulu(k6, "kunnostus", 65000, 40, "Jarrulevyt ja palat edessä")
    kulu(k6, "reklamaatio", 38000, 3, "Ostaja ilmoitti vikaantuneesta ilmastoinnin kompressorista, puolet kuluista meille")

    # Palaava auto: myyty yli vuosi sitten, nyt uudelleen meillä
    a7 = insert("ajoneuvo", liike_id=lid, rekisterinumero="AUD-202", vin="WAUZZZF40LA000007", merkki="Audi",
                malli="A4", mallitarkenne="40 TDI quattro Avant", vuosimalli=2020, kayttovoima="02",
                vaihteisto="4", korimalli="AC")
    vanha = kierros(a7, 61000, "toimitettu", "Autotalo Mallinen Oy", "autoliike", 2980000, 420,
                    asiakas="Autokeskus Demo Oy", myynti=3250000, myyntipv=395, maksettu=True)
    kulu(vanha, "kuljetus", 20000, 418)
    kierros(a7, 118000, "myynnissa", "Esimerkki Rahoitus Oy", "rahoitusyhtio", 2090000, 15, pyynti=2390000)
    for nimi in ["Neliveto", "Vetokoukku", "LED-ajovalot", "Navigaattori", "Istuinlämmitys edessä", "Peruutuskamera"]:
        v = query("SELECT id FROM varuste WHERE nimi = ? AND liike_id = ?", (nimi, lid), one=True)
        execute("INSERT INTO ajoneuvo_varuste (ajoneuvo_id, varuste_id) VALUES (?, ?)", (a7, v["id"]))

    k8 = auto("PEU-808", "VF3MCYHZRKS000008", "Peugeot", "3008", "1.2 PureTech Allure", 2019, "01", "2", "SUV",
              76000, "toimitettu", "Huutokauppa Esimerkki", "huutokauppa", 1450000, 70,
              asiakas="Autotalo Mallinen Oy", myynti=1690000, myyntipv=41, maksettu=True)
    kulu(k8, "huutokauppamaksu", 25000, 70)

    k9 = auto("TES-100", "5YJ3E7EB0LF000009", "Tesla", "Model 3", "Long Range AWD", 2020, "04", "2", "AA",
              89000, "myyty", "Esimerkki Rahoitus Oy", "rahoitusyhtio", 2150000, 30,
              asiakas="Autokeskus Demo Oy", myynti=2450000, myyntipv=6, alv="alv")
    kulu(k9, "pesu", 12000, 25)

    # Demo: vaiheiden tehtävät avoimille autoille (normaalisti syntyvät tilasiirrossa)
    for k in query("SELECT id, tila FROM kierto WHERE liike_id = ? AND tila NOT IN ('toimitettu','hylatty')", (lid,)):
        for p in query("SELECT * FROM tehtavapohja WHERE liike_id = ? AND tila = ?", (lid, k["tila"])):
            ep = (t + timedelta(days=(p["erapaiva_pv"] or 0) - 2)).isoformat() if p["erapaiva_pv"] is not None else None
            insert("tehtava", liike_id=lid, kierto_id=k["id"], tila_vaihe=k["tila"], otsikko=p["otsikko"],
                   rooli=p["rooli"], erapaiva=ep, luonut_id=admin)
