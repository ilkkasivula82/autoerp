"""Liiketoimintalogiikka: tilat, rahamuunnokset ja katelaskenta."""
from datetime import date, datetime

# (koodi, näyttönimi, väri-luokka). Järjestys = auton tavallinen elinkaari.
TILAT = [
    ("tarjottu", "Tarjottu", "t-tarjottu"),
    ("ostettu", "Ostettu", "t-ostettu"),
    ("tulossa", "Tulossa", "t-tulossa"),
    ("kunnostuksessa", "Kunnostuksessa", "t-kunnostus"),
    ("myynnissa", "Myynnissä", "t-myynnissa"),
    ("varattu", "Varattu", "t-varattu"),
    ("myyty", "Myyty", "t-myyty"),
    ("toimitettu", "Toimitettu", "t-toimitettu"),
    ("hylatty", "Hylätty", "t-hylatty"),
]
TILA_NIMI = {k: n for k, n, _ in TILAT}
TILA_LUOKKA = {k: c for k, _, c in TILAT}

# Sallitut siirrot. Taaksepäin pääsee aina edelliseen vaiheeseen (virheiden korjaus).
SIIRROT = {
    "tarjottu": ["ostettu", "hylatty"],
    "hylatty": ["tarjottu"],
    "ostettu": ["tulossa", "kunnostuksessa", "myynnissa", "tarjottu"],
    "tulossa": ["kunnostuksessa", "myynnissa", "ostettu"],
    "kunnostuksessa": ["myynnissa", "tulossa"],
    "myynnissa": ["varattu", "myyty", "kunnostuksessa"],
    "varattu": ["myyty", "myynnissa"],
    "myyty": ["toimitettu", "varattu", "myynnissa"],
    "toimitettu": ["myyty"],
}

# Tilat, joissa auto on omassa varastossa / sitoo pääomaa
VARASTOTILAT = ["ostettu", "tulossa", "kunnostuksessa", "myynnissa", "varattu"]

OSTOKANAVAT = [
    ("rahoitusyhtio", "Rahoitusyhtiö"),
    ("huutokauppa", "Huutokauppa"),
    ("autoliike", "Autoliike"),
    ("yksityinen", "Yksityinen"),
    ("muu", "Muu"),
]
YRITYSTYYPIT = OSTOKANAVAT

KULUTYYPIT = [
    ("huutokauppamaksu", "Huutokauppamaksu"),
    ("kuljetus", "Kuljetus"),
    ("huolto", "Huolto"),
    ("kunnostus", "Kunnostus / korjaus"),
    ("pesu", "Pesu / preppaus"),
    ("katsastus", "Katsastus"),
    ("renkaat", "Renkaat"),
    ("rekisterointi", "Rekisteröinti / verot"),
    ("reklamaatio", "Reklamaatio / jälkikorjaus"),
    ("hyvitys", "Hyvitys ostajalle"),
    ("muu", "Muu"),
]

ROOLIT = [
    ("admin", "Ylläpitäjä"),
    ("osto", "Osto"),
    ("myynti", "Myynti"),
    ("kunnostus", "Kunnostus / piha"),
    ("talous", "Talous"),
]

ALV_KASITTELYT = [
    ("marginaali", "Marginaaliverotus"),
    ("alv", "Normaali ALV"),
]


# ---------- Raha ----------

def euro_senteiksi(teksti):
    """'12 500,50' / '12500.5' / '' -> 1250050 / None"""
    if teksti is None:
        return None
    t = str(teksti).strip().replace(" ", "").replace(" ", "").replace("€", "")
    if not t:
        return None
    if "," in t and "." in t:
        t = t.replace(".", "")
    t = t.replace(",", ".")
    try:
        return int(round(float(t) * 100))
    except ValueError:
        return None


def euro(sentit, desimaalit=False):
    if sentit is None:
        return "–"
    arvo = sentit / 100
    if desimaalit:
        s = f"{arvo:,.2f}"
    else:
        s = f"{arvo:,.0f}"
    return s.replace(",", " ").replace(".", ",") + " €"


def euro_input(sentit):
    """Lomakkeen kenttään: 12500,50 tai 12500"""
    if sentit is None:
        return ""
    if sentit % 100 == 0:
        return str(sentit // 100)
    return f"{sentit / 100:.2f}".replace(".", ",")


# ---------- Päivämäärät ----------

def paivia_sitten(aika):
    if not aika:
        return None
    try:
        d = datetime.fromisoformat(str(aika)[:19]).date()
    except ValueError:
        try:
            d = date.fromisoformat(str(aika)[:10])
        except ValueError:
            return None
    return (date.today() - d).days


def pvm(aika):
    if not aika:
        return "–"
    s = str(aika)[:10]
    try:
        d = date.fromisoformat(s)
        return f"{d.day}.{d.month}.{d.year}"
    except ValueError:
        return s


# ---------- Kate ----------

def laske_kate(auto, kulut_veroton, alv_prosentti, myyntihinta=None, jalkikulut=0):
    """Laskee auton katteen.

    Marginaaliverotus (käytetyn tavaran erityisjärjestely):
      - ostohinta ja myyntihinta ovat sellaisenaan (myyntihinta sisältää veron)
      - vero = (myyntihinta - ostohinta) * r / (1 + r), jos voitto > 0
      - kunnostuskulut eivät pienennä veron laskentaperustetta, mutta niiden
        ALV vähennetään normaalisti, joten katteessa ne ovat verottomina
    Normaali ALV:
      - ostohinta, myyntihinta ja kulut verottomina
      - kate = myynti - osto - kulut

    auto: kierto-rivi (ostohinta, myyntihinta, pyyntihinta, alv_kasittely).
    kulut_veroton: KAIKKI kierron kulut verottomina (myös myynnin jälkeiset).
    jalkikulut: näistä myyntipäivän jälkeen kirjatut (reklamaatiot ym.).
    myyntihinta: jos None, käytetään toteutunutta myyntihintaa tai pyyntihintaa (arvio).
    Palauttaa dictin tai None, jos laskentaan ei ole tietoja.
    """
    osto = auto.get("ostohinta")
    if myyntihinta is None:
        myyntihinta = auto.get("myyntihinta")
        arvio = False
        if myyntihinta is None:
            myyntihinta = auto.get("pyyntihinta")
            arvio = True
    else:
        arvio = True
    if osto is None or myyntihinta is None:
        return None

    r = (alv_prosentti or 0) / 100
    kulut = kulut_veroton or 0

    if auto.get("alv_kasittely") == "alv":
        vero = 0
        nettomyynti = myyntihinta
        verollinen_myynti = int(round(myyntihinta * (1 + r)))
    else:
        voitto = myyntihinta - osto
        vero = int(round(voitto * r / (1 + r))) if voitto > 0 else 0
        nettomyynti = myyntihinta - vero
        verollinen_myynti = myyntihinta

    kate = nettomyynti - osto - kulut
    pohja = osto + kulut
    return {
        "arvio": arvio,
        "myynti": myyntihinta,
        "verollinen_myynti": verollinen_myynti,
        "marginaalivero": vero,
        "nettomyynti": nettomyynti,
        "osto": osto,
        "kulut": kulut,
        "hankintameno": pohja,
        "kate": kate,
        "jalkikulut": jalkikulut or 0,
        "kate_myyntihetki": kate + (jalkikulut or 0),
        "kate_pros": (kate / nettomyynti * 100) if nettomyynti else None,
    }
