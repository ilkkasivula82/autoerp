"""Käynnistys: paikallisesti `python wsgi.py`, tuotannossa `gunicorn wsgi:app`."""
from app import create_app

app = create_app()

if __name__ == "__main__":
    import os
    app.run(debug=True, port=int(os.environ.get("PORT", 5000)))
